import { Product } from "./types";

export const CURATED_40_PRODUCTS: Product[] = [
  {
    "id": "96",
    "name": "Barney's Botanicals 12mg Delta 9 Gummies 10ct",
    "slug": "barney-s-botanicals-12mg-delta-9-gummies-10ct",
    "description": "Barney's Botanicals 12mg Delta 9 Gummies 10ct provides balanced relaxation and euphoria through precisely dosed Delta-9 THC gummies in a delicious mixed fruit candy flavor. What's Inside\n• 1mg Delta-9 THC per gummy\n• Delicious mixed fruit candy flavor\n• Precisely dosed for consistent effects\n• 10-count pack\n• Third-party lab tested",
    "longDescription": "About This Product\nBarney's Botanicals 12mg Delta 9 Gummies 10ct provides balanced relaxation and euphoria through a carefully crafted Delta-9 THC gummy formula. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious mixed fruit candy flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Barney's Botanicals 12mg Delta 9 Gummies 10ct is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more Delta-9 THC products in our Delta 9 Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Mixed fruit candy flavor\n• Sweet balanced taste\n• Smooth clean finish\n\nWhy Choose This Product\n✔ 1mg Delta-9 THC per gummy\n✔ Delicious mixed fruit candy flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ 10-count pack\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 19.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/barneys-botanicals-12mg-delta-9-gummies-10ct.webp",
    "thc": "< 0.3% THC",
    "cbd": "12mg",
    "options": [
      "10-count",
      "30-count"
    ],
    "benefits": [
      "• 12mg Delta 9 THC per gummy",
      "• Available in 10-count and 30-count",
      "• Hemp-derived, federally compliant",
      "• Third-party lab tested"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 14,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Barney's Botanicals 12mg Delta 9 Gummies 10ct | CBD American Shaman of Hurst",
    "metaDescription": "Shop Barney's Botanicals 12mg Delta 9 Gummies 10ct at CBD American Shaman of Hurst. 12mg Delta 9 THC per gummy, available in 10-count and 30-count sizes, lab tested hemp gummy.",
    "tags": "Barney's Botanicals, Delta 9 Gummies, 12mg Delta 9, 10 Count, Hemp Gummies, Hemp-Derived, THC Gummies, Delta 9 THC, Edibles, Premium Gummies, Cannabis Gummies, Wellness",
    "altText": "Barney's Botanicals 12mg Delta 9 Gummies 10ct",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "98",
    "name": "Barney's Botanicals 30mg Delta 9 Gummies 30ct",
    "slug": "barney-s-botanicals-30mg-delta-9-gummies-30ct",
    "description": "Barney's Botanicals 30mg Delta 9 Gummies 30ct provides balanced relaxation and euphoria through precisely dosed Delta-9 THC gummies in a delicious mixed fruit candy flavor. What's Inside\n• 1mg Delta-9 THC per gummy\n• Delicious mixed fruit candy flavor\n• Precisely dosed for consistent effects\n• 30-count pack\n• Third-party lab tested",
    "longDescription": "About This Product\nBarney's Botanicals 30mg Delta 9 Gummies 30ct provides balanced relaxation and euphoria through a carefully crafted Delta-9 THC gummy formula. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious mixed fruit candy flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Barney's Botanicals 30mg Delta 9 Gummies 30ct is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more Delta-9 THC products in our Delta 9 Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Mixed fruit candy flavor\n• Sweet balanced taste\n• Smooth clean finish\n\nWhy Choose This Product\n✔ 1mg Delta-9 THC per gummy\n✔ Delicious mixed fruit candy flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ 30-count pack\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 74.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/barneys-botanicals-30mg-delta-9-gummies-30ct.webp",
    "thc": "< 0.3% THC",
    "cbd": "30mg",
    "options": [
      "30-count",
      "4-count sample ($19.99)"
    ],
    "benefits": [
      "• 30mg Delta 9 THC per gummy",
      "• 30-count bottle or 4-count sample",
      "• Higher-potency Delta 9 option",
      "• Third-party lab tested"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 36,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Barney's Botanicals 30mg Delta 9 Gummies 30ct | CBD American Shaman of Hurst",
    "metaDescription": "Shop Barney's Botanicals 30mg Delta 9 Gummies 30ct at CBD American Shaman of Hurst. 30mg Delta 9 THC per gummy. 30-count bottle or 4-count sample. Higher-potency Delta 9 option.",
    "tags": "Barney's Botanicals 30mg Delta 9 Gummies, Delta 9 gummies, hemp Delta 9 gummies, THC gummies, 30mg Delta 9, hemp-derived THC gummies, Delta 9 edibles, Barney's Botanicals gummies, premium Delta 9 gummies, 30 count gummies",
    "altText": "Barney's Botanicals 30mg Delta 9 Gummies 30ct",
    "created_at": "2026-08-20T18:28:06.053+00:00",
    "updated_at": "2026-08-20T18:28:06.053+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "32",
    "name": "CBD/CBN Gummies 3300mg – Sleep",
    "slug": "cbd-cbn-gummies-3300mg-sleep",
    "description": "Enjoy CBD/CBN Gummies 3300mg – Sleep delivers deep relaxation and restful sleep through precisely dosed CBD + CBN gummies in a delicious calming mixed berry flavor. What's Inside\n• 3300mg total CBD + CBN\n• Delicious calming mixed berry flavor\n• Precisely dosed for consistent effects\n• 3300mg total\n• Third-party lab tested",
    "longDescription": "About This Product\nEnjoy CBD/CBN Gummies 3300mg – Sleep provides deep relaxation and restful sleep through a carefully crafted CBD + CBN gummy formula. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious calming mixed berry flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Enjoy CBD/CBN Gummies 3300mg – Sleep is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more CBD + CBN products in our CBD Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Calming mixed berry flavor\n• Subtle sweet notes\n• Smooth clean finish\n\nWhy Choose This Product\n✔ 3300mg total CBD + CBN\n✔ Delicious calming mixed berry flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ 3300mg total\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 79.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/dark-cherry-cbd-cbn-thc-gummies-sleep-support.webp",
    "thc": "< 0.3% THC",
    "cbd": "3300mg",
    "options": [
      "NEEDS REVIEW"
    ],
    "benefits": [
      "• CBD + CBN sleep-support formula",
      "• Gummy format",
      "• Third-party lab tested",
      "• See duplicate note before publishing"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "CBD/CBN Sleep Gummies 3300mg | Shop CBD American Shaman of Hurst Texas Now",
    "metaDescription": "Shop CBD/CBN Gummies 3300mg – Sleep at CBD American Shaman of Hurst. CBD + CBN sleep-support formula. Gummy format. Third-party lab tested. Order online for Texas delivery.",
    "tags": "Enjoy Hemp, CBD Gummies, CBN Gummies, 3300mg CBD, Full Spectrum CBD, Sleep Gummies, Hemp-Derived, Nighttime Support, Wellness, CBD Edibles, Premium Gummies, Mixed Fruit",
    "altText": "Enjoy CBD/CBN Gummies 3300mg Sleep full-spectrum hemp gummies bottle",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "175",
    "name": "Cycling Frog Wintergreen THC Microdose Mints – 40 Count",
    "slug": "cycling-frog-wintergreen-thc-microdose-mints-40-count",
    "description": "Wintergreen THC Microdose Mints – 40 Count is a premium hemp-derived product available at CBD American Shaman of Hurst in Hurst, TX. What's Inside\n• Premium hemp-derived formula\n• Lab-tested for purity and potency\n• Consistent, reliable dosing\n• Available exclusively at CBD American Shaman of Hurst, Hurst",
    "longDescription": "About This Product\nWintergreen THC Microdose Mints – 40 Count is a carefully crafted hemp product available at CBD American Shaman of Hurst in Hurst, TX. Every unit is third-party lab tested to ensure purity, potency, and consistency.\n\nCBD American Shaman of Hurst is Hurst's trusted source for premium hemp-derived products including CBD, Delta-9, and specialty wellness items. We carry only brands we believe in, verified for quality at every step.\n\nWhy Choose This Product\n✔ Premium hemp-derived formula\n✔ Third-party lab tested for purity and potency\n✔ Precisely dosed for consistent, reliable effects\n✔ Available at CBD American Shaman of Hurst, Hurst, TX\n\nHow to Use\nFollow the product label instructions. Start low and go slow, especially if new to hemp products. Consult a healthcare professional if you have any questions about dosage or interactions.",
    "price": 17.99,
    "category": "edibles",
    "categoryLabel": "Edibles",
    "rating": 4.8,
    "image": "/images/wintergreen-thc-microdose-mints-40-count.webp",
    "thc": "< 0.3% THC",
    "cbd": "500mg CBD",
    "options": [
      "40-count"
    ],
    "benefits": [
      "• Microdose THC mints",
      "• 40 mints per tin",
      "• Wintergreen flavor",
      "• Discreet, on-the-go format"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Cycling Frog Wintergreen THC Microdose Mints – 40 Count",
    "metaDescription": "Shop Cycling Frog Wintergreen THC Microdose Mints – 40 Count at CBD American Shaman of Hurst. Microdose THC mints. 40 mints per tin. Wintergreen flavor. Available now at CBD American Shaman of Hurst.",
    "tags": "Wintergreen Mints, THC Mints, Microdose Mints, 40 Count, Hemp-Derived, THC Edibles, Wintergreen Flavor, Hemp THC, Premium Mints, Pocket Mints, Cannabis Edibles, Wellness",
    "altText": "Wintergreen THC Microdose Mints 40-count hemp-derived THC mint tin",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-22T16:26:07.283+00:00",
    "categories": [
      "edibles",
      "all"
    ]
  },
  {
    "id": "95",
    "name": "Drink Delta D9 Water – Maui Wowie Passion Fruit 20mg",
    "slug": "drink-delta-d9-water-maui-wowie-passion-fruit-20mg",
    "description": "Drink Delta D9 Water – Maui Wowie Passion Fruit 20mg delivers a refreshing tropical and exotic sweetness flavor infused with hemp-derived cannabinoids, offering a balanced and enjoyable cannabis beverage experience. What's Inside\n• 20mg Delta-9 THC per can\n• Tropical and exotic sweetness flavor\n• Sparkling Delta-9 THC beverage\n• Sold individually or by pack",
    "longDescription": "About This Product\nDrink Delta D9 Water – Maui Wowie Passion Fruit 20mg combines the bold flavor of Maui Wowie-inspired passion fruit with hemp-derived cannabinoids to create a refreshing sparkling cannabis beverage. Each can contains 20mg of hemp-derived Delta-9 THC, crafted for those seeking a more robust cannabis experience in a refreshing sparkling format.\n\nThe tropical and exotic sweetness pairs perfectly with crisp carbonation, delivering a refreshing drink that can be enjoyed chilled or served as a mocktail alternative. This Delta-9 THC beverage provides a flavorful way to unwind without alcohol.\n\nMade with natural fruit juice and hemp extract, this beverage is crafted to deliver consistent quality and smooth effects for social gatherings or relaxing evenings.\n\nBrowse more Delta-9 THC-infused beverages in our THC Drinks collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Tropical passion fruit flavor\n• Exotic floral notes\n• Clean refreshing finish\n\nWhy Choose This Product\n✔ 20mg Delta-9 THC per can\n✔ Sparkling cannabis beverage\n✔ Alcohol-free relaxation drink\n✔ Tropical and exotic sweetness flavor\n✔ Vegan, gluten-free, and non-GMO\n\nHow to Use\nStart with one can and wait about 30–60 minutes to understand the effects before consuming more.",
    "price": 6.99,
    "category": "drinks",
    "categoryLabel": "Drinks",
    "rating": 4.8,
    "image": "/images/drink-delta-d9-water-maui-wowie-passion-fruit-20mg.webp",
    "thc": "10mg Delta-9 THC",
    "cbd": "20mg",
    "options": [
      "Single can",
      "4-pack"
    ],
    "benefits": [
      "• 20mg Delta 9 THC per can",
      "• Maui Wowie passion fruit flavor",
      "• Available as single can or 4-pack",
      "• Refreshing THC-infused water"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 44,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Drink Delta D9 Water – Maui Wowie Passion Fruit 20mg",
    "metaDescription": "Shop Drink Delta D9 Water – Maui Wowie Passion Fruit 20mg at CBD American Shaman of Hurst. 20mg Delta 9 THC per can, passion fruit flavor, single can or 4-pack available now.",
    "tags": "Drink Delta D9 Water, Delta 9 Water, Maui Wowie, Passion Fruit, 20mg Delta 9, THC Beverage, Hemp Beverage, Hemp-Derived, Delta 9 Drink, Infused Water, Cannabis Drink, Wellness",
    "altText": "Drink Delta D9 Water Maui Wowie Passion Fruit 20mg hemp-derived Delta 9 beverage bottle",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "drinks",
      "all"
    ]
  },
  {
    "id": "94",
    "name": "Drink Delta D9 Water – Wedding Cake Blood Orange 20mg",
    "slug": "drink-delta-d9-water-wedding-cake-blood-orange-20mg",
    "description": "Drink Delta D9 Water – Wedding Cake Blood Orange 20mg delivers a refreshing rich citrus with sweet berry undertones flavor infused with hemp-derived cannabinoids, offering a balanced and enjoyable cannabis beverage experience. What's Inside\n• 20mg Delta-9 THC per can\n• Rich citrus with sweet berry undertones flavor\n• Sparkling Delta-9 THC beverage\n• Sold individually or by pack",
    "longDescription": "About This Product\nDrink Delta D9 Water – Wedding Cake Blood Orange 20mg combines the bold flavor of vibrant blood orange with hemp-derived cannabinoids to create a refreshing sparkling cannabis beverage. Each can contains 20mg of hemp-derived Delta-9 THC, crafted for those seeking a more robust cannabis experience in a refreshing sparkling format.\n\nThe rich citrus with sweet berry undertones pairs perfectly with crisp carbonation, delivering a refreshing drink that can be enjoyed chilled or served as a mocktail alternative. This Delta-9 THC beverage provides a flavorful way to unwind without alcohol.\n\nMade with natural fruit juice and hemp extract, this beverage is crafted to deliver consistent quality and smooth effects for social gatherings or relaxing evenings.\n\nBrowse more Delta-9 THC-infused beverages in our THC Drinks collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Bold blood orange flavor\n• Sweet-tart citrus notes\n• Crisp sparkling finish\n\nWhy Choose This Product\n✔ 20mg Delta-9 THC per can\n✔ Sparkling cannabis beverage\n✔ Alcohol-free relaxation drink\n✔ Rich citrus with sweet berry undertones flavor\n✔ Vegan, gluten-free, and non-GMO\n\nHow to Use\nStart with one can and wait about 30–60 minutes to understand the effects before consuming more.",
    "price": 6.99,
    "category": "drinks",
    "categoryLabel": "Drinks",
    "rating": 4.8,
    "image": "/images/drink-delta-d9-water-wedding-cake-blood-orange-20mg.webp",
    "thc": "10mg Delta-9 THC",
    "cbd": "20mg",
    "options": [
      "Single can",
      "4-pack"
    ],
    "benefits": [
      "• 20mg Delta 9 THC per can",
      "• Wedding Cake blood orange flavor",
      "• Available as single can or 4-pack",
      "• Refreshing THC-infused water"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 27,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Drink Delta D9 Water – Wedding Cake Blood Orange 20mg",
    "metaDescription": "Shop Drink Delta D9 Water – Wedding Cake Blood Orange 20mg at CBD American Shaman of Hurst. 20mg Delta 9 THC per can, blood orange flavor, single can or 4-pack available now.",
    "tags": "Drink Delta D9 Water, Delta 9 Water, Wedding Cake, Blood Orange, 20mg Delta 9, THC Beverage, Hemp Beverage, Hemp-Derived, Delta 9 Drink, Infused Water, Cannabis Drink, Wellness",
    "altText": "Drink Delta D9 Water Wedding Cake Blood Orange 20mg hemp-derived Delta 9 beverage bottle",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "drinks",
      "all"
    ]
  },
  {
    "id": "192",
    "name": "Enjoy Balance THC + CBD",
    "slug": "enjoy-balance-thc-cbd",
    "description": "Balance THC + CBD Gummies – 25mg (Hybrid) is a premium hemp-derived product available at CBD American Shaman of Hurst in Hurst, TX. What's Inside\n• Premium hemp-derived formula\n• Lab-tested for purity and potency\n• Consistent, reliable dosing\n• Available exclusively at CBD American Shaman of Hurst, Hurst",
    "longDescription": "About This Product\nBalance THC + CBD Gummies – 25mg (Hybrid) is a carefully crafted hemp product available at CBD American Shaman of Hurst in Hurst, TX. Every unit is third-party lab tested to ensure purity, potency, and consistency.\n\nCBD American Shaman of Hurst is Hurst's trusted source for premium hemp-derived products including CBD, Delta-9, and specialty wellness items. We carry only brands we believe in, verified for quality at every step.\n\nWhy Choose This Product\n✔ Premium hemp-derived formula\n✔ Third-party lab tested for purity and potency\n✔ Precisely dosed for consistent, reliable effects\n✔ Available at CBD American Shaman of Hurst, Hurst, TX\n\nHow to Use\nFollow the product label instructions. Start low and go slow, especially if new to hemp products. Consult a healthcare professional if you have any questions about dosage or interactions.",
    "price": 59.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/enjoy-live-rosin-delta-9-cbd-gummies-balance-25ct.webp",
    "thc": "< 0.3% THC",
    "cbd": "25mg",
    "options": [
      "30-count"
    ],
    "benefits": [
      "• 12.5mg THC + 12.5mg CBD per gummy",
      "• Balanced 1:1 THC-to-CBD ratio",
      "• 30-count bottle",
      "• Third-party lab tested"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": true,
    "isNew": false,
    "metaTitle": "Enjoy Balance THC + CBD Gummies | Shop CBD American Shaman of Hurst Texas",
    "metaDescription": "Shop Enjoy Balance THC + CBD at CBD American Shaman of Hurst. 12.5mg THC + 12.5mg CBD per gummy. Balanced 1:1 THC-to-CBD ratio. 30-count bottle. Order online for Texas delivery.",
    "tags": "Balance Gummies, THC Gummies, CBD Gummies, THC + CBD, 25mg Gummies, Hybrid Gummies, Hemp Gummies, Hemp-Derived, Edibles, THC Edibles, CBD Edibles, Wellness",
    "altText": "Enjoy Balance THC + CBD",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-22T16:30:49.899+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "30",
    "name": "Enjoy CBD/CBG Gummies 3300mg – Relief",
    "slug": "enjoy-cbd-cbg-gummies-3300mg-relief",
    "description": "Enjoy CBD/CBG Gummies 3300mg – Relief offers precise relief and balanced wellness through precisely dosed CBD + CBG gummies in a delicious soothing mixed fruit flavor. What's Inside\n• 3300mg total CBD + CBG\n• Delicious soothing mixed fruit flavor\n• Precisely dosed for consistent effects\n• 3300mg total\n• Third-party lab tested",
    "longDescription": "About This Product\nEnjoy CBD/CBG Gummies 3300mg – Relief provides targeted relief and balanced wellness through a carefully crafted CBD + CBG gummy formula. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious soothing mixed fruit flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Enjoy CBD/CBG Gummies 3300mg – Relief is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more CBD + CBG products in our CBD Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Mixed fruit candy flavor\n• Light sweet taste\n• Smooth clean finish\n\nWhy Choose This Product\n✔ 3300mg total CBD + CBG\n✔ Delicious soothing mixed fruit flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ 3300mg total\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 69.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/enjoy-cbd-cbg-gummies-3300mg-relief.webp",
    "thc": "< 0.3% THC",
    "cbd": "3300mg",
    "options": [
      "30-count"
    ],
    "benefits": [
      "• CBD + CBG relief formula",
      "• 30 gummies per bottle",
      "• Third-party lab tested",
      "• Non-intoxicating hemp formula"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 47,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Enjoy CBD/CBG Relief Gummies 3300mg | Shop CBD American Shaman of Hurst",
    "metaDescription": "Shop Enjoy CBD/CBG Gummies 3300mg – Relief at CBD American Shaman of Hurst. CBD + CBG relief formula. 30 gummies per bottle. Third-party lab tested. Order online for Texas delivery.",
    "tags": "Enjoy Hemp, CBD Gummies, CBG Gummies, 3300mg CBD, Full Spectrum CBD, Relief Gummies, Hemp-Derived, Turmeric, Panax Ginseng, Wellness, Daily Support, Mixed Fruit",
    "altText": "Enjoy CBD/CBG Gummies 3300mg Relief full-spectrum hemp gummies bottle",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "126",
    "name": "Enjoy Live Rosin Chill Delta 9 Gummies 600mg",
    "slug": "enjoy-live-rosin-chill-delta-9-gummies-600mg",
    "description": "Enjoy Live Rosin Chill Delta 9 Gummies 600mg provides balanced relaxation and euphoria through precisely dosed Delta-9 THC gummies in a delicious cool mixed fruit flavor. What's Inside\n• 600mg total Delta-9 THC\n• Delicious cool mixed fruit flavor\n• Precisely dosed for consistent effects\n• 600mg total\n• Third-party lab tested",
    "longDescription": "About This Product\nEnjoy Live Rosin Chill Delta 9 Gummies 600mg provides balanced relaxation and euphoria through a carefully crafted Delta-9 THC gummy formula. These gummies are crafted with premium live rosin extract for superior terpene preservation and authentic full-plant flavor. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious cool mixed fruit flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Enjoy Live Rosin Chill Delta 9 Gummies 600mg is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more Delta-9 THC products in our Delta 9 Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Mixed fruit candy flavor\n• Cool smooth taste\n• Smooth clean finish\n\nWhy Choose This Product\n✔ 600mg total Delta-9 THC\n✔ Delicious cool mixed fruit flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ 600mg total\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 74.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/enjoy-live-rosin-chill-delta-9-gummies-600mg.webp",
    "thc": "< 0.3% THC",
    "cbd": "600mg",
    "options": [
      "2-count sample ($10.99)",
      "40-count"
    ],
    "benefits": [
      "• Live rosin Delta 9 THC gummies",
      "• 40 gummies per bag",
      "• 2-count sample available for $10.99",
      "• Full-spectrum live rosin extract"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 18,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Enjoy Live Rosin Chill Delta 9 Gummies 600mg | CBD American Shaman of Hurst",
    "metaDescription": "Shop Enjoy Live Rosin Chill Delta 9 Gummies 600mg at CBD American Shaman of Hurst. Live rosin Delta 9 THC gummies. 40 gummies per bag. 2-count sample available for $10.99.",
    "tags": "Enjoy Hemp, Live Rosin Gummies, Delta 9 Gummies, 600mg Delta 9, Hemp-Derived, THC Gummies, Live Rosin, Hemp Gummies, Edibles, Premium Gummies, Cannabis Gummies, Wellness",
    "altText": "Enjoy Live Rosin Chill Delta 9 Gummies 600mg hemp-derived live rosin gummy package",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "120",
    "name": "Enjoy Live Rosin Delta 9 + CBD Gummies Balance 25ct",
    "slug": "enjoy-live-rosin-delta-9-cbd-gummies-balance-25ct",
    "description": "Enjoy Live Rosin Delta 9 + CBD Gummies Balance 25ct delivers a balanced experience with 12.5 mg Delta-9 THC and 12.5 mg CBD per gummy, infused with premium live rosin extract and available in a delicious mixed fruit flavor.\n\nWhat's Inside\n12.5 mg Delta-9 THC + 12.5 mg CBD per gummy\nPremium live rosin extract\nMixed fruit flavor\n25-count pack\nThird-party lab tested for purity and potency",
    "longDescription": "About This Product\n\nEnjoy Live Rosin Delta 9 + CBD Gummies Balance 25ct features a balanced blend of 12.5 mg Delta-9 THC and 12.5 mg CBD in each gummy, crafted with premium live rosin extract to preserve naturally occurring terpenes and deliver an authentic full-spectrum hemp experience.\n\nEach gummy is precisely dosed for consistency and comes in a flavorful mixed fruit variety, making it a convenient option for those seeking a balanced cannabinoid product.\n\nMade with premium hemp-derived ingredients and independently third-party lab tested for purity and potency, Enjoy Live Rosin Delta 9 + CBD Gummies Balance 25ct is available at CBD American Shaman of Hurst, Hurst's trusted destination for quality hemp products.\n\nBrowse more Delta-9 products in the CBD American Shaman of Hurst Delta-9 collection.\n\nTaste & Aroma\n\n• Mixed fruit flavor\n• Sweet, fruity taste\n• Smooth, enjoyable finish\n\nWhy Choose This Product\n\n✔ 12.5 mg Delta-9 THC + 12.5 mg CBD per gummy\n✔ Premium live rosin extract\n✔ Delicious mixed fruit flavor\n✔ Precisely dosed for consistent servings\n✔ 25-count pack\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived ingredients\n\nHow to Use\n\nStart with one gummy (12.5 mg Delta-9 THC + 12.5 mg CBD) and wait at least 60–90 minutes before considering an additional serving, especially if you are new to THC edibles. Follow the product label instructions and consume responsibly.",
    "price": 54.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/enjoy-live-rosin-delta-9-cbd-gummies-balance-25ct.webp",
    "thc": "< 0.3% THC",
    "cbd": "500mg CBD",
    "options": [
      "25-count"
    ],
    "benefits": [
      "• 12.5mg Delta 9 THC + 12.5mg CBD per gummy",
      "• Balanced 1:1 ratio",
      "• Live rosin extract",
      "• 25-count bottle"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 12,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Enjoy Live Rosin Delta 9 + CBD Gummies Balance 25ct",
    "metaDescription": "Shop Enjoy Live Rosin Delta 9 + CBD Gummies Balance 25ct at CBD American Shaman of Hurst. 12.5mg Delta 9 THC + 12.5mg CBD per gummy. Balanced 1:1 ratio. Live rosin extract.",
    "tags": "Enjoy Hemp, Live Rosin Gummies, Delta 9 Gummies, CBD Gummies, Balance Gummies, 25 Count, Hemp-Derived, Live Rosin, THC Gummies, Edibles, Premium Gummies, Wellness",
    "altText": "Enjoy Live Rosin Delta 9 and CBD Gummies Balance 25-count hemp-derived live rosin gummy package",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-21T03:25:53.419+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "27",
    "name": "Enjoy Live Rosin Delta 9 Gummies 300mg – Bliss",
    "slug": "enjoy-live-rosin-delta-9-gummies-300mg-bliss",
    "description": "Enjoy Live Rosin Delta 9 Gummies 300mg – Bliss provides balanced relaxation and euphoria through precisely dosed Delta-9 THC gummies in a delicious sweet blissful fruit flavor. What's Inside\n• 300mg total Delta-9 THC\n• Delicious sweet blissful fruit flavor\n• Precisely dosed for consistent effects\n• 300mg total\n• Third-party lab tested",
    "longDescription": "About This Product\nEnjoy Live Rosin Delta 9 Gummies 300mg – Bliss provides balanced relaxation and euphoria through a carefully crafted Delta-9 THC gummy formula. These gummies are crafted with premium live rosin extract for superior terpene preservation and authentic full-plant flavor. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious sweet blissful fruit flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Enjoy Live Rosin Delta 9 Gummies 300mg – Bliss is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more Delta-9 THC products in our Delta 9 Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Sweet mixed fruit flavor\n• Smooth candy taste\n• Smooth clean finish\n\nWhy Choose This Product\n✔ 300mg total Delta-9 THC\n✔ Delicious sweet blissful fruit flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ 300mg total\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 44.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/enjoy-live-rosin-delta-9-gummies-300mg-bliss.webp",
    "thc": "< 0.3% THC",
    "cbd": "300mg",
    "options": [
      "25-count"
    ],
    "benefits": [
      "• Live rosin Delta 9 THC gummies",
      "• 25 gummies per bottle",
      "• 'Bliss' euphoric flavor blend",
      "• Full-spectrum live rosin extract"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 51,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Enjoy Live Rosin Delta 9 Gummies 300mg – Bliss | CBD American Shaman of Hurst",
    "metaDescription": "Shop Enjoy Live Rosin Delta 9 Gummies 300mg – Bliss at CBD American Shaman of Hurst. Live rosin Delta 9 THC gummies. 25 gummies per bottle. 'Bliss' euphoric flavor blend. Order...",
    "tags": "Enjoy Hemp, Live Rosin Gummies, Delta 9 Gummies, 300mg Delta 9, Bliss, Hemp-Derived, THC Gummies, Live Rosin, Hemp Gummies, Edibles, Premium Gummies, Wellness",
    "altText": "Enjoy Live Rosin Delta 9 Gummies 300mg Bliss hemp-derived live rosin gummy package",
    "created_at": "2026-08-20T18:28:06.053+00:00",
    "updated_at": "2026-08-20T18:28:06.053+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "122",
    "name": "Enjoy Live Rosin Delta 9 Gummies Euphoria 25ct",
    "slug": "enjoy-live-rosin-delta-9-gummies-euphoria-25ct",
    "description": "Enjoy Live Rosin Delta 9 Gummies Euphoria 25ct provides balanced relaxation and euphoria through precisely dosed Delta-9 THC gummies in a delicious sweet fruity euphoria blend flavor. What's Inside\n• Delta-9 THC formula\n• Delicious sweet fruity euphoria blend flavor\n• Precisely dosed for consistent effects\n• 25-count pack\n• Third-party lab tested",
    "longDescription": "About This Product\nEnjoy Live Rosin Delta 9 Gummies Euphoria 25ct provides balanced relaxation and euphoria through a carefully crafted Delta-9 THC gummy formula. These gummies are crafted with premium live rosin extract for superior terpene preservation and authentic full-plant flavor. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious sweet fruity euphoria blend flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Enjoy Live Rosin Delta 9 Gummies Euphoria 25ct is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more Delta-9 THC products in our Delta 9 Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Sweet fruit candy flavor\n• Bold festive taste\n• Smooth clean finish\n\nWhy Choose This Product\n✔Delta-9 THC formula\n✔ Delicious sweet fruity euphoria blend flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ 25-count pack\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 44.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/enjoy-live-rosin-delta-9-gummies-euphoria-25ct.webp",
    "thc": "< 0.3% THC",
    "cbd": "500mg CBD",
    "options": [
      "25-count"
    ],
    "benefits": [
      "• Live rosin Delta 9 THC gummies",
      "• 25 gummies per bottle",
      "• 'Euphoria' flavor blend",
      "• Full-spectrum live rosin extract"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 39,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Enjoy Live Rosin Delta 9 Gummies Euphoria 25ct | CBD American Shaman of Hurst",
    "metaDescription": "Shop Enjoy Live Rosin Delta 9 Gummies Euphoria 25ct at CBD American Shaman of Hurst. Live rosin Delta 9 THC gummies. 25 gummies per bottle. 'Euphoria' flavor blend. Adults 21+ only.",
    "tags": "Enjoy Hemp, Live Rosin Gummies, Delta 9 Gummies, Euphoria, 25 Count, Hemp-Derived, THC Gummies, Live Rosin, Hemp Gummies, Edibles, Premium Gummies, Wellness",
    "altText": "Enjoy Live Rosin Delta 9 Gummies Euphoria 25-count hemp-derived live rosin gummy package",
    "created_at": "2026-08-20T18:28:06.053+00:00",
    "updated_at": "2026-08-20T18:28:06.053+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "127",
    "name": "Enjoy Live Rosin Euphoria Delta 9 Gummies 600mg",
    "slug": "enjoy-live-rosin-euphoria-delta-9-gummies-600mg",
    "description": "Enjoy Live Rosin Euphoria Delta 9 Gummies 600mg provides balanced relaxation and euphoria through precisely dosed Delta-9 THC gummies in a delicious sweet fruity euphoria blend flavor. What's Inside\n• 600mg total Delta-9 THC\n• Delicious sweet fruity euphoria blend flavor\n• Precisely dosed for consistent effects\n• 600mg total\n• Third-party lab tested",
    "longDescription": "About This Product\nEnjoy Live Rosin Euphoria Delta 9 Gummies 600mg provides balanced relaxation and euphoria through a carefully crafted Delta-9 THC gummy formula. These gummies are crafted with premium live rosin extract for superior terpene preservation and authentic full-plant flavor. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious sweet fruity euphoria blend flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Enjoy Live Rosin Euphoria Delta 9 Gummies 600mg is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more Delta-9 THC products in our Delta 9 Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Sweet fruit candy flavor\n• Bold festive taste\n• Smooth clean finish\n\nWhy Choose This Product\n✔ 600mg total Delta-9 THC\n✔ Delicious sweet fruity euphoria blend flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ 600mg total\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 74.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/enjoy-live-rosin-euphoria-delta-9-gummies-600mg.webp",
    "thc": "< 0.3% THC",
    "cbd": "600mg",
    "options": [
      "40-count"
    ],
    "benefits": [
      "• Live rosin Delta 9 THC gummies",
      "• 40 gummies per bag",
      "• 'Euphoria' flavor blend",
      "• Full-spectrum live rosin extract"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 27,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Enjoy Live Rosin Euphoria Delta 9 Gummies 600mg | CBD American Shaman of Hurst",
    "metaDescription": "Shop Enjoy Live Rosin Euphoria Delta 9 Gummies 600mg at CBD American Shaman of Hurst. Live rosin Delta 9 THC gummies. 40 gummies per bag. 'Euphoria' flavor blend. Adults 21+ only.",
    "tags": "Enjoy Hemp, Live Rosin Gummies, Euphoria, Delta 9 Gummies, 600mg Delta 9, Hemp-Derived, THC Gummies, Live Rosin, Hemp Gummies, Edibles, Premium Gummies, Wellness",
    "altText": "Enjoy Live Rosin Euphoria Delta 9 Gummies 600mg hemp-derived live rosin gummy package",
    "created_at": "2026-08-20T18:28:06.053+00:00",
    "updated_at": "2026-08-20T18:28:06.053+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "190",
    "name": "Enjoy Sleep 3300mg CBD + CBN Mixed Fruit Gummies",
    "slug": "enjoy-sleep-3300mg-cbd-cbn-mixed-fruit-gummies",
    "description": "Sleep CBD Gummies – Mixed Fruit is a premium hemp-derived product available at CBD American Shaman of Hurst in Hurst, TX. What's Inside\n• Premium hemp-derived formula\n• Lab-tested for purity and potency\n• Consistent, reliable dosing\n• Available exclusively at CBD American Shaman of Hurst, Hurst",
    "longDescription": "About This Product\nSleep CBD Gummies – Mixed Fruit is a carefully crafted hemp product available at CBD American Shaman of Hurst in Hurst, TX. Every unit is third-party lab tested to ensure purity, potency, and consistency.\n\nCBD American Shaman of Hurst is Hurst's trusted source for premium hemp-derived products including CBD, Delta-9, and specialty wellness items. We carry only brands we believe in, verified for quality at every step.\n\nWhy Choose This Product\n✔ Premium hemp-derived formula\n✔ Third-party lab tested for purity and potency\n✔ Precisely dosed for consistent, reliable effects\n✔ Available at CBD American Shaman of Hurst, Hurst, TX\n\nHow to Use\nFollow the product label instructions. Start low and go slow, especially if new to hemp products. Consult a healthcare professional if you have any questions about dosage or interactions.",
    "price": 5.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/enjoy-cbdcbn-gummies-3300mg-sleep.webp",
    "thc": "< 0.3% THC",
    "cbd": "500mg CBD",
    "options": [
      "2-count trial pack",
      "30-count bottle"
    ],
    "benefits": [
      "• 100mg CBD + CBN per gummy",
      "• Mixed fruit flavor gummies",
      "• Available as a 2-count trial or 30-count bottle",
      "• Formulated to support restful sleep"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Enjoy Sleep 3300mg CBD + CBN Mixed Fruit Gummies | CBD American Shaman of Hurst",
    "metaDescription": "Shop Enjoy Sleep 3300mg CBD + CBN Mixed Fruit Gummies at CBD American Shaman of Hurst. 100mg CBD + CBN per gummy, mixed fruit flavor, formulated to support restful sleep tonight.",
    "tags": "Sleep CBD Gummies, Mixed Fruit, CBD Gummies, Hemp Gummies, Hemp-Derived, Nighttime Support, CBD Edibles, Wellness, Premium CBD, Daily Wellness, Mixed Fruit Gummies, CBD",
    "altText": "Sleep CBD Gummies in mixed fruit flavor hemp-derived gummy bottle",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "74",
    "name": "Hometown Hero Delta 9 Cocoa Crisp Cereal Bites",
    "slug": "hometown-hero-delta-9-cocoa-crisp-cereal-bites",
    "description": "Hometown Hero Delta 9 Cocoa Crisp Cereal Bites provides balanced relaxation and euphoria through precisely dosed Delta-9 THC gummies in a delicious rich cocoa crisp cereal flavor. What's Inside\n• Delta-9 THC formula\n• Delicious rich cocoa crisp cereal flavor\n• Precisely dosed for consistent effects\n• resealable pack\n• Third-party lab tested",
    "longDescription": "About This Product\nHometown Hero Delta 9 Cocoa Crisp Cereal Bites provides balanced relaxation and euphoria through a carefully crafted Delta-9 THC gummy formula. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious rich cocoa crisp cereal flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Hometown Hero Delta 9 Cocoa Crisp Cereal Bites is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more Delta-9 THC products in our Delta 9 Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Rich cocoa cereal flavor\n• Chocolatey sweet taste\n• Smooth clean finish\n\nWhy Choose This Product\n✔ Delta-9 THC formula\n✔ Delicious rich cocoa crisp cereal flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ Resealable pack\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 49.99,
    "category": "edibles",
    "categoryLabel": "Edibles",
    "rating": 4.8,
    "image": "/images/hometown-hero-delta-9-cocoa-crisp-cereal-bites.webp",
    "thc": "< 0.3% THC",
    "cbd": "300mg CBD",
    "options": [
      "1 bag (15 pieces)"
    ],
    "benefits": [
      "• 300mg Delta 9 THC per bag",
      "• 15 cereal bite pieces per bag",
      "• Cocoa crisp cereal flavor",
      "• Sold by the bag only"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 31,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Hometown Hero Delta 9 Cocoa Crisp Cereal Bites | CBD American Shaman of Hurst",
    "metaDescription": "Shop Hometown Hero Delta 9 Cocoa Crisp Cereal Bites at CBD American Shaman of Hurst. 300mg Delta 9 THC per bag. 15 cereal bite pieces per bag. Cocoa crisp cereal flavor. Order...",
    "tags": "Hometown Hero, Delta 9, Cocoa Crisp, Cereal Bites, THC Edibles, Hemp-Derived, Delta 9 Edibles, Hemp Snacks, Premium Edibles, Chocolate Flavor, Wellness, Cannabis Edibles",
    "altText": "Hometown Hero Delta 9 Cocoa Crisp Cereal Bites hemp-derived edible package",
    "created_at": "2026-08-20T18:28:06.053+00:00",
    "updated_at": "2026-08-20T18:28:06.053+00:00",
    "categories": [
      "edibles",
      "all"
    ]
  },
  {
    "id": "73",
    "name": "Hometown Hero Delta 9 Fruity Rainbow Cereal Bites",
    "slug": "hometown-hero-delta-9-fruity-rainbow-cereal-bites",
    "description": "Hometown Hero Delta 9 Fruity Rainbow Cereal Bites provides balanced relaxation and euphoria through precisely dosed Delta-9 THC gummies in a delicious nostalgic fruity rainbow cereal flavor. What's Inside\n• Delta-9 THC formula\n• Delicious nostalgic fruity rainbow cereal flavor\n• Precisely dosed for consistent effects\n• resealable pack\n• Third-party lab tested",
    "longDescription": "About This Product\nHometown Hero Delta 9 Fruity Rainbow Cereal Bites provides balanced relaxation and euphoria through a carefully crafted Delta-9 THC gummy formula. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious nostalgic fruity rainbow cereal flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Hometown Hero Delta 9 Fruity Rainbow Cereal Bites is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more Delta-9 THC products in our Delta 9 Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Nostalgic fruity cereal flavor\n• Sweet milk-soaked taste\n• Smooth clean finish\n\nWhy Choose This Product\n✔ Delta-9 THC formula\n✔ Delicious nostalgic fruity rainbow cereal flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ Resealable pack\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 49.99,
    "category": "edibles",
    "categoryLabel": "Edibles",
    "rating": 4.8,
    "image": "/images/hometown-hero-delta-9-fruity-rainbow-cereal-bites.webp",
    "thc": "< 0.3% THC",
    "cbd": "500mg CBD",
    "options": [
      "1 bag (15 pieces)"
    ],
    "benefits": [
      "• Delta 9 THC cereal bites",
      "• 15 pieces per bag",
      "• Fruity rainbow cereal flavor",
      "• Sold by the bag only"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 13,
    "isBestSeller": false,
    "isNew": true,
    "metaTitle": "Hometown Hero Delta 9 Fruity Rainbow Cereal Bites | CBD American Shaman of Hurst",
    "metaDescription": "Shop Hometown Hero Delta 9 Fruity Rainbow Cereal Bites at CBD American Shaman of Hurst. Delta 9 THC cereal bites. 15 pieces per bag. Fruity rainbow cereal flavor. Adults 21+ only.",
    "tags": "Hometown Hero, Delta 9, Fruity Rainbow, Cereal Bites, THC Edibles, Hemp-Derived, Delta 9 Edibles, Hemp Snacks, Premium Edibles, Fruity Flavor, Wellness, Cannabis Edibles",
    "altText": "Hometown Hero Delta 9 Fruity Rainbow Cereal Bites hemp-derived edible package",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-22T16:23:19.351+00:00",
    "categories": [
      "edibles",
      "all"
    ]
  },
  {
    "id": "119",
    "name": "Hometown Hero Delta 9 Live Rosin Gummies Blue Dream 10ct",
    "slug": "hometown-hero-delta-9-live-rosin-gummies-blue-dream-10ct",
    "description": "Hometown Hero Delta 9 Live Rosin Gummies Blue Dream 10ct provides balanced relaxation and euphoria through precisely dosed Delta-9 THC gummies in a delicious sweet blueberry and vanilla flavor. What's Inside\n• Delta-9 THC formula\n• Delicious sweet blueberry and vanilla flavor\n• Precisely dosed for consistent effects\n• 10-count pack\n• Third-party lab tested",
    "longDescription": "About This Product\nHometown Hero Delta 9 Live Rosin Gummies Blue Dream 10ct provides balanced relaxation and euphoria through a carefully crafted Delta-9 THC gummy formula. These gummies are crafted with premium live rosin extract for superior terpene preservation and authentic full-plant flavor. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious sweet blueberry and vanilla flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Hometown Hero Delta 9 Live Rosin Gummies Blue Dream 10ct is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more Delta-9 THC products in our Delta 9 Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Sweet blueberry and vanilla flavor\n• Light floral notes\n• Smooth clean finish\n\nWhy Choose This Product\n✔ Delta-9 THC formula\n✔ Delicious sweet blueberry and vanilla flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ 10-count pack\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 69.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/hometown-hero-delta-9-live-rosin-gummies-blue-dream-10ct.webp",
    "thc": "< 0.3% THC",
    "cbd": "500mg CBD",
    "options": [
      "10-count"
    ],
    "benefits": [
      "• Live rosin Delta 9 THC gummies",
      "• Blue Dream hybrid flavor",
      "• 10-count package",
      "• Full-spectrum live rosin extract"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 26,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Hometown Hero Delta 9 Live Rosin Gummies Blue Dream 10ct",
    "metaDescription": "Shop Hometown Hero Delta 9 Live Rosin Gummies Blue Dream 10ct at CBD American Shaman of Hurst. Live rosin Delta 9 THC gummies. Blue Dream hybrid flavor. 10-count package. Order...",
    "tags": "Hometown Hero, Live Rosin Gummies, Delta 9 Gummies, Blue Dream, 10 Count, Hemp-Derived, THC Gummies, Live Rosin, Hemp Gummies, Edibles, Premium Gummies, Wellness",
    "altText": "Hometown Hero Delta 9 Live Rosin Gummies Blue Dream 10-count hemp-derived gummy package",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "118",
    "name": "Hometown Hero Delta 9 Live Rosin Gummies Gelato 10ct",
    "slug": "hometown-hero-delta-9-live-rosin-gummies-gelato-10ct",
    "description": "Hometown Hero Delta 9 Live Rosin Gummies Gelato 10ct provides balanced relaxation and euphoria through precisely dosed Delta-9 THC gummies in a delicious sweet creamy gelato flavor. What's Inside\n• Delta-9 THC formula\n• Delicious sweet creamy gelato flavor\n• Precisely dosed for consistent effects\n• 10-count pack\n• Third-party lab tested",
    "longDescription": "About This Product\nHometown Hero Delta 9 Live Rosin Gummies Gelato 10ct provides balanced relaxation and euphoria through a carefully crafted Delta-9 THC gummy formula. These gummies are crafted with premium live rosin extract for superior terpene preservation and authentic full-plant flavor. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious sweet creamy gelato flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Hometown Hero Delta 9 Live Rosin Gummies Gelato 10ct is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more Delta-9 THC products in our Delta 9 Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Sweet creamy gelato flavor\n• Dessert-inspired taste\n• Smooth clean finish\n\nWhy Choose This Product\n✔ Delta-9 THC formula\n✔ Delicious sweet creamy gelato flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ 10-count pack\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 69.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/hometown-hero-delta-9-live-rosin-gummies-gelato-10ct.webp",
    "thc": "< 0.3% THC",
    "cbd": "500mg CBD",
    "options": [
      "NEEDS REVIEW (title says 10ct",
      "feedback text says 30 — confirm actual count)"
    ],
    "benefits": [
      "• Live rosin Delta 9 THC gummies",
      "• Gelato flavor",
      "• Package size to be confirmed",
      "• Full-spectrum live rosin extract"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 34,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Hometown Hero Delta 9 Live Rosin Gummies Gelato 10ct",
    "metaDescription": "Shop Hometown Hero Delta 9 Live Rosin Gummies Gelato 10ct at CBD American Shaman of Hurst. Live rosin Delta 9 THC gummies. Gelato flavor. Package size to be confirmed. Order...",
    "tags": "Hometown Hero, Live Rosin Gummies, Delta 9 Gummies, Gelato, 10 Count, Hemp-Derived, THC Gummies, Live Rosin, Hemp Gummies, Edibles, Premium Gummies, Wellness",
    "altText": "Hometown Hero Delta 9 Live Rosin Gummies Gelato 10-count hemp-derived gummy package",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "117",
    "name": "Hometown Hero Delta 9 Live Rosin Gummies Grand Daddy Purple 10ct",
    "slug": "hometown-hero-delta-9-live-rosin-gummies-grand-daddy-purple-10ct",
    "description": "Hometown Hero Delta 9 Live Rosin Gummies Grand Daddy Purple 10ct provides balanced relaxation and euphoria through precisely dosed Delta-9 THC gummies in a delicious sweet grape and berry flavor. What's Inside\n• Delta-9 THC formula\n• Delicious sweet grape and berry flavor\n• Precisely dosed for consistent effects\n• 10-count pack\n• Third-party lab tested",
    "longDescription": "About This Product\nHometown Hero Delta 9 Live Rosin Gummies Grand Daddy Purple 10ct provides balanced relaxation and euphoria through a carefully crafted Delta-9 THC gummy formula. These gummies are crafted with premium live rosin extract for superior terpene preservation and authentic full-plant flavor. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious sweet grape and berry flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Hometown Hero Delta 9 Live Rosin Gummies Grand Daddy Purple 10ct is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more Delta-9 THC products in our Delta 9 Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Rich grape and berry flavor\n• Sweet fruity taste\n• Smooth clean finish\n\nWhy Choose This Product\n✔ Delta-9 THC formula\n✔ Delicious sweet grape and berry flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ 10-count pack\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 69.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/hometown-hero-delta-9-live-rosin-gummies-grand-daddy-purple-10ct.webp",
    "thc": "< 0.3% THC",
    "cbd": "500mg CBD",
    "options": [
      "10-count"
    ],
    "benefits": [
      "• Live rosin Delta 9 THC gummies",
      "• Grand Daddy Purple indica flavor",
      "• 10-count package",
      "• Full-spectrum live rosin extract"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 31,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Hometown Hero Delta 9 Live Rosin Gummies Grand | CBD American Shaman of Hurst",
    "metaDescription": "Shop Hometown Hero Delta 9 Live Rosin Gummies Grand Daddy Purple 10ct at CBD American Shaman of Hurst. Live rosin THC gummies, indica flavor, 10-count package available now.",
    "tags": "Hometown Hero, Live Rosin Gummies, Delta 9 Gummies, Grand Daddy Purple, 10 Count, Hemp-Derived, THC Gummies, Live Rosin, Hemp Gummies, Edibles, Premium Gummies, Wellness",
    "altText": "Hometown Hero Delta 9 Live Rosin Gummies Grand Daddy Purple 10-count hemp-derived gummy package",
    "created_at": "2026-08-20T18:28:06.053+00:00",
    "updated_at": "2026-08-20T18:28:06.053+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "178",
    "name": "Hometown Hero Northern Lights Live Rosin THC Gummies – Indica",
    "slug": "hometown-hero-northern-lights-live-rosin-thc-gummies-indica",
    "description": "Northern Lights Live Rosin THC Gummies – Indica is a premium hemp-derived product available at CBD American Shaman of Hurst in Hurst, TX. What's Inside\n• Premium hemp-derived formula\n• Lab-tested for purity and potency\n• Consistent, reliable dosing\n• Available exclusively at CBD American Shaman of Hurst, Hurst",
    "longDescription": "About This Product\nNorthern Lights Live Rosin THC Gummies – Indica is a carefully crafted hemp product available at CBD American Shaman of Hurst in Hurst, TX. Every unit is third-party lab tested to ensure purity, potency, and consistency.\n\nCBD American Shaman of Hurst is Hurst's trusted source for premium hemp-derived products including CBD, Delta-9, and specialty wellness items. We carry only brands we believe in, verified for quality at every step.\n\nWhy Choose This Product\n✔ Premium hemp-derived formula\n✔ Third-party lab tested for purity and potency\n✔ Precisely dosed for consistent, reliable effects\n✔ Available at CBD American Shaman of Hurst, Hurst, TX\n\nHow to Use\nFollow the product label instructions. Start low and go slow, especially if new to hemp products. Consult a healthcare professional if you have any questions about dosage or interactions.",
    "price": 69.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/hometown-hero-delta-9-live-rosin-gummies-blue-dream-10ct.webp",
    "thc": "< 0.3% THC",
    "cbd": "500mg CBD",
    "options": [
      "10-count"
    ],
    "benefits": [
      "• Live rosin Delta 9 THC gummies",
      "• Northern Lights indica flavor",
      "• 10-count package",
      "• Full-spectrum live rosin extract"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": true,
    "isNew": false,
    "metaTitle": "Hometown Hero Northern Lights Live Rosin THC | CBD American Shaman of Hurst",
    "metaDescription": "Shop Hometown Hero Northern Lights Live Rosin THC Gummies – Indica at CBD American Shaman of Hurst. Live rosin Delta 9 THC gummies. Northern Lights indica flavor. 10-count package.",
    "tags": "Northern Lights, Live Rosin Gummies, Indica Gummies, THC Gummies, Hemp Gummies, Hemp-Derived, Live Rosin, THC Edibles, Premium Gummies, Cannabis Gummies, Wellness, Edibles",
    "altText": "Northern Lights Live Rosin THC Gummies Indica hemp-derived gummy package",
    "created_at": "2026-08-20T18:28:06.053+00:00",
    "updated_at": "2026-08-22T16:30:51.913+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "182",
    "name": "Nowadays 10 mg THC Shot",
    "slug": "nowadays-10-mg-thc-shot",
    "description": "10mg THC Shots – Hemp-Infused Beverage is a premium hemp-derived product available at CBD American Shaman of Hurst in Hurst, TX. What's Inside\n• Premium hemp-derived formula\n• Lab-tested for purity and potency\n• Consistent, reliable dosing\n• Available exclusively at CBD American Shaman of Hurst, Hurst",
    "longDescription": "About This Product\n10mg THC Shots – Hemp-Infused Beverage is a carefully crafted hemp product available at CBD American Shaman of Hurst in Hurst, TX. Every unit is third-party lab tested to ensure purity, potency, and consistency.\n\nCBD American Shaman of Hurst is Hurst's trusted source for premium hemp-derived products including CBD, Delta-9, and specialty wellness items. We carry only brands we believe in, verified for quality at every step.\n\nWhy Choose This Product\n✔ Premium hemp-derived formula\n✔ Third-party lab tested for purity and potency\n✔ Precisely dosed for consistent, reliable effects\n✔ Available at CBD American Shaman of Hurst, Hurst, TX\n\nHow to Use\nFollow the product label instructions. Start low and go slow, especially if new to hemp products. Consult a healthcare professional if you have any questions about dosage or interactions.",
    "price": 7.99,
    "category": "drinks",
    "categoryLabel": "Drinks",
    "rating": 4.8,
    "image": "/images/10mg-thc-shots-hemp-infused-beverage.webp",
    "thc": "< 0.3% THC",
    "cbd": "10mg",
    "options": [
      "Single serving (2 fl oz)"
    ],
    "benefits": [
      "• 10mg THC per shot",
      "• Single 2 fl oz serving",
      "• Fast-acting shot format",
      "• Convenient one-time use"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Nowadays 10mg THC Shot | Shop Online at CBD American Shaman of Hurst TX",
    "metaDescription": "Shop Nowadays 10 mg THC Shot at CBD American Shaman of Hurst. 10mg THC per shot. Single 2 fl oz serving. Fast-acting shot format. Order online for Texas delivery. Adults 21+ only.",
    "tags": "10mg THC Shots, Hemp Beverage, Hemp-Infused, THC Drink, 10mg THC, Hemp-Derived THC, Ready-to-Drink, THC Beverage, Hemp Drinks, Cannabis Beverage, THC Wellness, Edibles",
    "altText": "10mg THC Shots – Premium Hemp-Infused Beverage",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "drinks",
      "all"
    ]
  },
  {
    "id": "158",
    "name": "Proleve – CBD Daily Gummies – 50 mg, 30 Count",
    "slug": "proleve-cbd-daily-gummies-50-mg-30-count",
    "description": "Proleve – CBD Daily Gummies – 50 mg, 30 Count supports everyday wellness — now available at CBD American Shaman of Hurst in Hurst, TX and calm balance through precisely dosed CBD gummies in a delicious light mixed fruit flavor. What's Inside\n• 50mg total CBD\n• Delicious light mixed fruit flavor\n• Precisely dosed for consistent effects\n• 50mg total\n• Third-party lab tested",
    "longDescription": "About This Product\nProleve – CBD Daily Gummies – 50 mg, 30 Count supports daily balance and wellbeing through a thoughtfully formulated CBD gummy formula. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious light mixed fruit flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Proleve – CBD Daily Gummies – 50 mg, 30 Count is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more CBD products in our CBD Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Light mixed fruit flavor\n• Gentle sweet taste\n• Smooth clean finish\n\nWhy Choose This Product\n✔ 50mg total CBD\n✔ Delicious light mixed fruit flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ 50mg total\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 64.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/proleve-cbd-daily-gummies-50-mg-30-count.webp",
    "thc": "< 0.3% THC",
    "cbd": "1500mg CBD (50mg per gummy)",
    "options": [
      "30-count"
    ],
    "benefits": [
      "• 50mg CBD per gummy",
      "• 1500mg CBD total per 30-count bottle",
      "• Daily-use CBD formula",
      "• Third-party lab tested"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 46,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Proleve – CBD Daily Gummies – 50 mg, 30 Count | CBD American Shaman of Hurst",
    "metaDescription": "Shop Proleve – CBD Daily Gummies – 50 mg, 30 Count at CBD American Shaman of Hurst. 50mg CBD per gummy. 1500mg CBD total per 30-count bottle. Daily-use CBD formula. Adults 21+ only.",
    "tags": "Proleve, CBD Gummies, Daily Gummies, 50mg CBD, 30 Count, Hemp-Derived, CBD Edibles, Wellness, Premium CBD, Hemp Gummies, Daily Wellness, CBD",
    "altText": "Proleve CBD Daily Gummies 50mg 30-count hemp-derived CBD gummy bottle",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "157",
    "name": "Proleve – CBD Night Gummies – 50 mg, 30 Count",
    "slug": "proleve-cbd-night-gummies-50-mg-30-count",
    "description": "Proleve – CBD Night Gummies – 50 mg, 30 Count supports everyday wellness — now available at CBD American Shaman of Hurst in Hurst, TX and calm balance through precisely dosed CBD gummies in a delicious mixed berry for sleep flavor. What's Inside\n• 50mg total CBD\n• Delicious mixed berry for sleep flavor\n• Precisely dosed for consistent effects\n• 50mg total\n• Third-party lab tested",
    "longDescription": "About This Product\nProleve – CBD Night Gummies – 50 mg, 30 Count supports daily balance and wellbeing through a thoughtfully formulated CBD gummy formula. Every gummy is carefully dosed for consistent, dependable results.\n\nAvailable in a delicious mixed berry for sleep flavor, these gummies make adding cannabinoids to your daily routine simple and enjoyable — perfect for relaxing after a long day, supporting sleep, or enhancing your overall sense of wellbeing.\n\nMade with premium hemp-derived ingredients and rigorously tested for purity and potency, Proleve – CBD Night Gummies – 50 mg, 30 Count is a trusted choice at CBD American Shaman of Hurst, Hurst's premier hemp shop.\n\nBrowse more CBD products in our CBD Products collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Mixed berry flavor\n• Subtle calming sweetness\n• Smooth clean finish\n\nWhy Choose This Product\n✔ 50mg total CBD\n✔ Delicious mixed berry for sleep flavor\n✔ Precisely dosed for consistent, reliable effects\n✔ 50mg total\n✔ Third-party lab tested for purity and potency\n✔ Made with premium hemp-derived extract\n\nHow to Use\nStart with one gummy and wait 30–60 minutes to understand the effects before consuming more.",
    "price": 64.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/proleve-cbd-night-gummies-50-mg-30-count.webp",
    "thc": "< 0.3% THC",
    "cbd": "500mg CBD",
    "options": [
      "30-count"
    ],
    "benefits": [
      "• 50mg CBD per gummy",
      "• 30-count bottle",
      "• Nighttime CBD formula",
      "• Third-party lab tested"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 42,
    "isBestSeller": true,
    "isNew": true,
    "metaTitle": "Proleve – CBD Night Gummies – 50 mg, 30 Count | CBD American Shaman of Hurst",
    "metaDescription": "Shop Proleve – CBD Night Gummies – 50 mg, 30 Count at CBD American Shaman of Hurst. 50mg CBD per gummy. 30-count bottle. Nighttime CBD formula. Order online for Texas delivery.",
    "tags": "Proleve, CBD Gummies, Night Gummies, 50mg CBD, 30 Count, Hemp-Derived, CBD Edibles, Nighttime Support, Wellness, Premium CBD, Hemp Gummies, Daily Wellness",
    "altText": "Proleve CBD Night Gummies 50mg 30-count hemp-derived CBD gummy bottle",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-21T16:42:51.851+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "140",
    "name": "Proleve CBD 2000 Warming Roll On",
    "slug": "proleve-cbd-2000-warming-roll-on",
    "description": "CBD Roll-On Warming 2000mg provides targeted soothing warmth for muscle aches and tension through a convenient roll-on applicator with 2000mg CBD. What's Inside\n• 2000mg CBD per roll-on\n• Warming sensation formula\n• Easy roll-on applicator\n• Fast-acting topical CBD\n• Non-greasy formula",
    "longDescription": "About This Product\nCBD Roll-On Warming 2000mg delivers soothing warmth for muscle aches and tension using a convenient roll-on applicator. Infused with 2000mg of premium hemp-derived CBD, this topical is designed for targeted application directly to areas of discomfort, providing localized relief without systemic effects.\n\nThe warming formula provides a noticeable warming sensation that helps soothe muscles and joints after exercise, physical activity, or daily wear. The roll-on design makes application clean, mess-free, and portable.\n\nAvailable at CBD American Shaman of Hurst, this CBD roll-on is ideal for athletes, active individuals, and anyone seeking targeted relief.\n\nTaste & Aroma\n• Warming sensation on skin\n• Light herbal CBD notes\n• Non-greasy, fast-absorbing formula\n\nWhy Choose This Product\n✔ 2000mg CBD per roll-on\n✔ Warming sensation formula\n✔ Convenient roll-on applicator\n✔ Fast-acting topical CBD\n✔ Non-greasy and portable\n✔ Third-party lab tested\n\nHow to Use\nApply directly to the affected area and massage in gently. Use as needed. For external use only — avoid contact with eyes and broken skin.",
    "price": 39.99,
    "category": "pet",
    "categoryLabel": "Pet",
    "rating": 4.8,
    "image": "/images/cbd-roll-on-warming-2000mg.webp",
    "thc": "< 0.3% THC",
    "cbd": "2000mg",
    "options": [
      "Roll-on"
    ],
    "benefits": [
      "• 2000mg CBD per roll-on",
      "• Warming relief formula",
      "• Easy, mess-free roll-on application",
      "• Targeted topical support"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": true,
    "isNew": false,
    "metaTitle": "Proleve CBD Warming Roll-On 2000mg | Shop CBD American Shaman of Hurst TX",
    "metaDescription": "Shop Proleve CBD 2000 Warming Roll On at CBD American Shaman of Hurst. 2000mg CBD per roll-on. Warming relief formula. Easy, mess-free roll-on application. Available now at CBD American Shaman of Hurst.",
    "tags": "CBD Roll-On, Warming Roll-On, 2000mg CBD, CBD Topical, Hemp-Derived, Warming Gel, CBD Relief, Muscle Relief, Wellness, Premium CBD, Topical CBD",
    "altText": "CBD Roll-On Warming 2000mg hemp-derived CBD topical roll-on bottle",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-21T16:44:53.304+00:00",
    "categories": [
      "pet",
      "topicals",
      "all"
    ]
  },
  {
    "id": "141",
    "name": "Proleve CBD Roll-On Cooling 2000mg",
    "slug": "proleve-cbd-roll-on-cooling-2000mg",
    "description": "CBD Roll-On Cooling 2000mg provides targeted refreshing cooling relief for soreness and inflammation through a convenient roll-on applicator with 2000mg CBD. What's Inside\n• 2000mg CBD per roll-on\n• Cooling sensation formula\n• Easy roll-on applicator\n• Fast-acting topical CBD\n• Non-greasy formula",
    "longDescription": "About This Product\nCBD Roll-On Cooling 2000mg delivers refreshing cooling relief for soreness and inflammation using a convenient roll-on applicator. Infused with 2000mg of premium hemp-derived CBD, this topical is designed for targeted application directly to areas of discomfort, providing localized relief without systemic effects.\n\nThe cooling formula provides a noticeable cooling sensation that helps soothe muscles and joints after exercise, physical activity, or daily wear. The roll-on design makes application clean, mess-free, and portable.\n\nAvailable at CBD American Shaman of Hurst, this CBD roll-on is ideal for athletes, active individuals, and anyone seeking targeted relief.\n\nTaste & Aroma\n• Cooling sensation on skin\n• Light herbal CBD notes\n• Non-greasy, fast-absorbing formula\n\nWhy Choose This Product\n✔ 2000mg CBD per roll-on\n✔ Cooling sensation formula\n✔ Convenient roll-on applicator\n✔ Fast-acting topical CBD\n✔ Non-greasy and portable\n✔ Third-party lab tested\n\nHow to Use\nApply directly to the affected area and massage in gently. Use as needed. For external use only — avoid contact with eyes and broken skin.",
    "price": 39.99,
    "category": "pet",
    "categoryLabel": "Pet",
    "rating": 4.8,
    "image": "/images/cbd-roll-on-cooling-2000mg.webp",
    "thc": "< 0.3% THC",
    "cbd": "2000mg",
    "options": [
      "Roll-on"
    ],
    "benefits": [
      "• 2000mg CBD per roll-on",
      "• Cooling menthol-style relief",
      "• Easy, mess-free roll-on application",
      "• Targeted topical support"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": true,
    "isNew": false,
    "metaTitle": "Proleve CBD Cooling Roll-On 2000mg | Shop CBD American Shaman of Hurst TX",
    "metaDescription": "Shop Proleve CBD Roll-On Cooling 2000mg at CBD American Shaman of Hurst. 2000mg CBD per roll-on. Cooling menthol-style relief. Easy, mess-free roll-on application. Adults 21+ only.",
    "tags": "Proleve, CBD Roll-On, Cooling Roll-On, 2000mg CBD, CBD Topical, Hemp-Derived CBD, Cooling Gel, CBD Relief, Muscle Relief, Wellness, Topical CBD, CBD",
    "altText": "Proleve CBD Roll-On Cooling 2000mg hemp-derived CBD topical roll-on bottle.",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-21T16:42:55.115+00:00",
    "categories": [
      "pet",
      "topicals",
      "all"
    ]
  },
  {
    "id": "170",
    "name": "Road Trip Desert Stardust Mushroom Chocolate Bar – Strawberry Crunch",
    "slug": "road-trip-desert-stardust-mushroom-chocolate-bar-strawberry-crunch",
    "description": "Desert Stardust Mushroom Chocolate Bar – Strawberry Crunch is a premium mushroom-infused chocolate bar available at CBD American Shaman of Hurst in Hurst, TX.\n\nWhat's Inside\nPremium mushroom-infused formula\nThird-party lab tested for quality and consistency\nPrecisely crafted for reliable serving consistency\nAvailable exclusively at CBD American Shaman of Hurst, Hurst",
    "longDescription": "About This Product\n\nDesert Stardust Mushroom Chocolate Bar – Strawberry Crunch is a carefully crafted mushroom-infused chocolate bar available at CBD American Shaman of Hurst in Hurst, TX. Every bar is third-party lab tested to help ensure quality, consistency, and purity.\n\nCBD American Shaman of Hurst is Hurst's trusted source for premium wellness products and specialty items. We carefully select brands that meet high standards for quality and transparency.\n\nWhy Choose This Product\n\n✔ Premium mushroom-infused formula\n✔ Third-party lab tested for quality and consistency\n✔ Crafted for reliable serving consistency\n✔ Available at CBD American Shaman of Hurst, Hurst, TX\n\nHow to Use\n\nFollow the serving instructions provided on the product packaging. If you're trying this product for the first time, begin with a low serving and wait before consuming more to assess your individual response. If you have questions about whether this product is appropriate for you, consult a qualified healthcare professional.",
    "price": 24.99,
    "category": "edibles",
    "categoryLabel": "Edibles",
    "rating": 4.8,
    "image": "/images/desert-stardust-mushroom-chocolate-bar-starawberry-crunch.webp",
    "thc": "< 0.3% THC",
    "cbd": "500mg CBD",
    "options": [
      "1 bar"
    ],
    "benefits": [
      "• Mushroom-based chocolate bar",
      "• Strawberry crunch flavor",
      "• Single-bar size",
      "• Available online",
      "check in-store availability"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Road Trip Desert Stardust Mushroom Chocolate Bar | CBD American Shaman of Hurst",
    "metaDescription": "Shop Road Trip Desert Stardust Mushroom Chocolate Bar – Strawberry Crunch at CBD American Shaman of Hurst. Mushroom-based chocolate bar. Strawberry crunch flavor. Single-bar size.",
    "tags": "Desert Stardust, Mushroom Chocolate, Strawberry Crunch, Chocolate Bar, Mushroom-Infused, Gourmet Chocolate, Edibles, Premium Chocolate, Strawberry Flavor, Wellness, Chocolate Edible, Mushroom Bar",
    "altText": "Desert Stardust Strawberry Crunch mushroom-infused chocolate bar packaging",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-21T16:52:34.885+00:00",
    "categories": [
      "edibles",
      "all"
    ]
  },
  {
    "id": "prod-1783883747826",
    "name": "Willie's Remedy THC Infused Seltzer Black Cherry Lime",
    "slug": "willie-s-remedy-thc-infused-seltzer-black-cherry-lime",
    "description": "Willie's Remedy THC Infused Seltzer Black Cherry Lime 10mg is a refreshing hemp-derived sparkling beverage featuring 10mg Delta 9 THC with CBD, CBG, and L-theanine in a bold black cherry and lime flavor.",
    "longDescription": "Enjoy a refreshing twist on hemp beverages with Willie's & Soda Black Cherry Lime THC Seltzer 10mg. Crafted with premium hemp-derived cannabinoids, each sparkling can delivers 10mg of Delta 9 THC, along with CBD, CBG, and L-theanine for a smooth and balanced beverage experience.\n\nThe bold combination of juicy black cherry and zesty lime creates a crisp, lightly carbonated drink that's perfect for relaxing evenings, social gatherings, or as an alternative to traditional alcoholic beverages. Its ready-to-drink can makes it easy to enjoy wherever your day takes you.\n\nAvailable at CBD American Shaman of Hurst, this premium THC seltzer is made with quality hemp ingredients and is third-party lab tested for consistency and quality.\n\nTaste & Aroma\n\n• Bold black cherry flavor\n• Refreshing citrus lime finish\n• Crisp sparkling carbonation\n\nWhy Choose This Product\n\n✔ 10mg hemp-derived Delta 9 THC per can\n✔ Includes CBD, CBG & L-theanine\n✔ Delicious black cherry and lime flavor\n✔ Refreshing sparkling beverage\n✔ Ready-to-drink convenience\n✔ Third-party lab tested\n\nHow to Use\n\nServe chilled and enjoy one can. Allow sufficient time before consuming additional servings. Intended for adults 21+ only.",
    "price": 7.99,
    "category": "drinks",
    "categoryLabel": "Drinks",
    "rating": 4.8,
    "image": "/images/dark-cherry-cbd-cbn-thc-gummies-sleep-support.webp",
    "thc": "< 0.3% THC",
    "cbd": "500gm CBD",
    "options": [
      "12 fl oz"
    ],
    "benefits": [
      "• 10mg Delta 9 THC per can",
      "• Bold black cherry & lime flavor",
      "• Includes CBD, CBG, and L-theanine",
      "• A flavorful alternative to alcoholic drinks"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Compliant Hemp Extract",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": true,
    "isNew": false,
    "metaTitle": "Willie's Remedy THC Infused Seltzer Black Cherry Lime",
    "metaDescription": "Shop Willie's Remedy THC Infused Seltzer Black Cherry Lime at CBD American Shaman of Hurst. Refreshing sparkling hemp drink. Bold black cherry & lime. 10mg Delta 9 THC per can.",
    "tags": "Willie's, THC Seltzer, Black Cherry Lime, 10mg THC, Delta 9 THC, CBD, CBG, L-Theanine, Sparkling Beverage, Hemp Beverage, Ready-to-Drink, THC Drink",
    "altText": "Willie's & Soda Black Cherry Lime 10mg hemp-derived Delta 9 THC sparkling seltzer can.",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "drinks",
      "all"
    ]
  },
  {
    "id": "prod-1783884305648",
    "name": "Willie's Remedy THC Infused Seltzer Strawberry Watermelon",
    "slug": "willie-s-remedy-thc-infused-seltzer-strawberry-watermelon",
    "description": "Willie's & Soda Strawberry Watermelon Sparkling Beverage with CBD & CBC is a refreshing hemp-derived sparkling drink featuring 20mg CBD and 10mg CBC in a delicious strawberry watermelon flavor.",
    "longDescription": "Enjoy a crisp and refreshing hemp-infused sparkling beverage with Willie's & Soda Strawberry Watermelon Sparkling Beverage. Each ready-to-drink can contains 20mg CBD and 10mg CBC, offering a smooth and refreshing way to enjoy premium hemp cannabinoids.\n\nThe sweet blend of ripe strawberries and juicy watermelon creates a light, fruity taste with crisp carbonation, making it a perfect choice for relaxing afternoons, social occasions, or as a refreshing alcohol-free beverage.\n\nAvailable at CBD American Shaman of Hurst, this premium hemp sparkling beverage is made with high-quality ingredients and is third-party lab tested for purity, quality, and consistency.\n\nTaste & Aroma\n• Sweet strawberry flavor\n• Juicy watermelon finish\n• Crisp sparkling carbonation\n\nWhy Choose This Product\n\n✔ 20mg CBD per can\n✔ 10mg CBC per can\n✔ Refreshing strawberry watermelon flavor\n✔ Ready-to-drink sparkling beverage\n✔ Convenient single-serve can\n✔ Third-party lab tested for quality and purity\n\nHow to Use\n\nServe chilled for the best taste. Enjoy one can as desired. Intended for adults 21+ only.",
    "price": 7.99,
    "category": "drinks",
    "categoryLabel": "Drinks",
    "rating": 4.8,
    "image": "/images/10mg-thc-shots-hemp-infused-beverage.webp",
    "thc": "< 0.3% THC",
    "cbd": "20 mg CBD",
    "options": [
      "12 fl oz"
    ],
    "benefits": [
      "• 10mg Delta 9 THC per can",
      "• Sweet strawberry watermelon flavor",
      "• Includes CBD, CBG, and L-theanine",
      "• A flavorful alternative to alcoholic drinks"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Compliant Hemp Extract",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": true,
    "isNew": false,
    "metaTitle": "Willie's Remedy THC Infused Seltzer Strawberry Watermelon",
    "metaDescription": "Shop Willie's Remedy THC Infused Seltzer Strawberry Watermelon at CBD American Shaman of Hurst. Refreshing sparkling hemp drink. Sweet flavor. 10mg Delta 9 THC per can. Order now.",
    "tags": "Willie's, THC Seltzer, Strawberry Watermelon, 10mg THC, Delta 9 THC, CBD, CBG, L-Theanine, Sparkling Beverage, Hemp Beverage, Ready-to-Drink, THC Drink",
    "altText": "Willie's & Soda Strawberry Watermelon 10mg hemp-derived Delta 9 THC sparkling seltzer can",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "drinks",
      "all"
    ]
  },
  {
    "id": "prod-1783882226404",
    "name": "Willie's THC Social Tonic 10mg 750ml Spirit",
    "slug": "willie-s-thc-social-tonic-10mg-750ml-spirit",
    "description": "Willie's THC Social Tonic 10mg is a hemp-derived sparkling beverage crafted for social occasions. Each can contains 10mg of Delta 9 THC with a refreshing flavor and a convenient ready-to-drink format.",
    "longDescription": "Willie's THC Social Tonic 10mg is a premium hemp-derived sparkling beverage designed for adults looking for a refreshing alternative to traditional drinks. Each can delivers 10mg of hemp-derived Delta 9 THC in a crisp, ready-to-drink formula that's easy to enjoy at gatherings, celebrations, or while relaxing.\n\nMade with quality hemp ingredients, this social tonic combines a light sparkling finish with balanced flavor for a smooth drinking experience. The convenient single-serve can is perfect for enjoying at home or on the go.\n\nAvailable at CBD American Shaman of Hurst, this THC-infused beverage offers a delicious way to explore hemp-derived Delta 9 products in an easy-to-enjoy drink.\n\nTaste & Aroma\n\n• Crisp sparkling beverage\n• Refreshing citrus-forward flavor\n• Smooth finish with light carbonation\n\nWhy Choose This Product\n\n✔ 10mg hemp-derived Delta 9 THC per can\n✔ Refreshing sparkling beverage\n✔ Convenient ready-to-drink format\n✔ Great for social occasions\n✔ Made with premium hemp ingredients\n✔ Third-party lab tested\n\nHow to Use\n\nEnjoy one chilled can and allow adequate time before consuming more. Effects may take time to develop depending on individual tolerance. Intended for adults 21+.",
    "price": 69.99,
    "category": "drinks",
    "categoryLabel": "Drinks",
    "rating": 4.8,
    "image": "/images/10mg-thc-shots-hemp-infused-beverage.webp",
    "thc": "10mg Delta 9 THC per can",
    "cbd": "0mg CBD",
    "options": [
      "750 ml"
    ],
    "benefits": [
      "• 10mg THC per serving",
      "• 750 ml bottle meant for shot-style pours",
      "• A spirit-style alcohol alternative",
      "• Ideal for social gatherings"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Compliant Hemp Extract",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 25,
    "isBestSeller": true,
    "isNew": true,
    "metaTitle": "Willie's THC Social Tonic 10mg 750ml Spirit | CBD American Shaman of Hurst",
    "metaDescription": "Shop Willie's THC Social Tonic 10mg 750ml Spirit at CBD American Shaman of Hurst. 10mg THC per serving. 750 ml bottle meant for shot-style pours. A spirit-style alcohol alternative.",
    "tags": "Willie's, THC Social Tonic, Delta 9 THC, 10mg THC, THC Beverage, Sparkling Drink, Hemp Beverage, Ready-to-Drink, Hemp-Derived, THC Drink, Cannabis Beverage, Wellness",
    "altText": "Willie's THC Social Tonic 10mg hemp-derived Delta 9 sparkling beverage can",
    "created_at": "2026-08-20T18:28:06.053+00:00",
    "updated_at": "2026-08-29T17:21:38.408+00:00",
    "categories": [
      "drinks",
      "all"
    ]
  },
  {
    "id": "prod-1783882836256",
    "name": "Willie's THC Social Tonic 5mg 750ml Spirit",
    "slug": "willie-s-thc-social-tonic-5mg-750ml-spirit",
    "description": "Willie's THC Social Tonic 5mg is a premium hemp-derived social beverage featuring 5mg Delta 9 THC, plus CBD, CBG, and L-theanine in a refreshing ready-to-drink formula for relaxed social moments.",
    "longDescription": "Willie's THC Social Tonic 5mg is a premium hemp-derived beverage crafted for those looking for a low-dose THC experience in a convenient ready-to-drink format. Each serving contains 5mg of hemp-derived Delta 9 THC, balanced with CBD, CBG, and L-theanine to deliver a smooth, approachable experience.\n\nMade with refreshing citrus and tropical fruit flavors, this social tonic is perfect for relaxing at home, spending time with friends, or enjoying as an alternative to traditional alcoholic beverages. The fast-acting formula and portable bottle make it an easy choice for both new and experienced hemp consumers.\n\nAvailable at CBD American Shaman of Hurst, Willie's THC Social Tonic 5mg offers a flavorful and convenient way to enjoy premium hemp-derived cannabinoids.\n\nTaste & Aroma\n\n• Bright lemon and lime notes\n• Tropical passion fruit flavor\n• Light cannabis botanical finish\n\nWhy Choose This Product\n\n✔ 5mg hemp-derived Delta 9 THC per serving\n✔ Includes CBD, CBG, and L-theanine\n✔ Refreshing citrus and tropical flavor\n✔ Convenient ready-to-drink format\n✔ Fast-acting hemp beverage\n✔ Third-party lab tested\n\nHow to Use\n\nShake gently if needed and enjoy chilled. Start with one serving and allow adequate time before consuming more. Intended for adults 21+ only.",
    "price": 54.99,
    "category": "drinks",
    "categoryLabel": "Drinks",
    "rating": 4.8,
    "image": "/images/cbd-roll-on-cooling-2000mg.webp",
    "thc": "5mg Delta 9 THC per serving",
    "cbd": "2mg CBD per serving",
    "options": [
      "750 ml"
    ],
    "benefits": [
      "• 5mg THC per serving",
      "• 750 ml bottle, multiple servings",
      "• A spirit-style alcohol alternative",
      "• Great for shared social occasions"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Compliant Hemp Extract",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": true,
    "isNew": false,
    "metaTitle": "Willie's THC Social Tonic 5mg 750ml Spirit | CBD American Shaman of Hurst",
    "metaDescription": "Shop Willie's THC Social Tonic 5mg 750ml Spirit at CBD American Shaman of Hurst. 5mg THC per serving. 750 ml bottle, multiple servings. A spirit-style alcohol alternative.",
    "tags": "Willie's, THC Social Tonic, 5mg THC, Delta 9 THC, CBD, CBG, L-Theanine, Hemp Beverage, THC Drink, Ready-to-Drink, Hemp-Derived, Wellness",
    "altText": "Willie's THC Social Tonic 5mg hemp-derived Delta 9 beverage bottle with CBD, CBG, and L-theanine.",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "drinks",
      "all"
    ]
  },
  {
    "id": "177",
    "name": "Wyld Blood Orange THC + CBC Gummies – 30ct",
    "slug": "wyld-blood-orange-thc-cbc-gummies-30ct",
    "description": "Wyld Blood Orange THC + CBC Gummies – Bliss is a premium hemp-derived product available at CBD American Shaman of Hurst in Hurst, TX. What's Inside\n• Premium hemp-derived formula\n• Lab-tested for purity and potency\n• Consistent, reliable dosing\n• Available exclusively at CBD American Shaman of Hurst, Hurst",
    "longDescription": "About This Product\nWyld Blood Orange THC + CBC Gummies – Bliss is a carefully crafted hemp product available at CBD American Shaman of Hurst in Hurst, TX. Every unit is third-party lab tested to ensure purity, potency, and consistency.\n\nCBD American Shaman of Hurst is Hurst's trusted source for premium hemp-derived products including CBD, Delta-9, and specialty wellness items. We carry only brands we believe in, verified for quality at every step.\n\nWhy Choose This Product\n✔ Premium hemp-derived formula\n✔ Third-party lab tested for purity and potency\n✔ Precisely dosed for consistent, reliable effects\n✔ Available at CBD American Shaman of Hurst, Hurst, TX\n\nHow to Use\nFollow the product label instructions. Start low and go slow, especially if new to hemp products. Consult a healthcare professional if you have any questions about dosage or interactions.",
    "price": 34.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/wyld-blood-orange-thc-cbc-gummies-bliss.webp",
    "thc": "< 0.3% THC",
    "cbd": "500mg CBD",
    "options": [
      "30-count",
      "10-count ($34.99)"
    ],
    "benefits": [
      "• THC + CBC blend gummies",
      "• Blood orange flavor",
      "• Available in 30-count or 10-count ($34.99)",
      "• Third-party lab tested"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Wyld Blood Orange THC + CBC Gummies – 30ct | CBD American Shaman of Hurst",
    "metaDescription": "Shop Wyld Blood Orange THC + CBC Gummies – 30ct at CBD American Shaman of Hurst. THC + CBC blend gummies. Blood orange flavor. Available in 30-count or 10-count ($34.99). Order...",
    "tags": "Wyld, Blood Orange, THC Gummies, CBC Gummies, Bliss, Hemp-Derived, Hemp Gummies, THC Edibles, Premium Gummies, Blood Orange Flavor, Wellness, Edibles",
    "altText": "Wyld Blood Orange THC and CBC Gummies Bliss hemp-derived gummy package",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "63",
    "name": "Wyld CBD Sparkling Water – Blackberry 50mg",
    "slug": "wyld-cbd-sparkling-water-blackberry-50mg",
    "description": "Wyld CBD Sparkling Water – Blackberry 50mg CBD delivers a refreshing bold sweet-tart berry flavor infused with hemp-derived cannabinoids, offering a balanced and enjoyable cannabis beverage experience. What's Inside\n• 50mg CBD per can\n• Bold sweet-tart berry flavor\n• Sparkling CBD beverage\n• Sold individually or by pack",
    "longDescription": "About This Product\nWyld CBD Sparkling Water – Blackberry 50mg combines the bold flavor of ripe blackberries with hemp-derived cannabinoids to create a refreshing sparkling cannabis beverage. Each can contains 50mg of hemp-derived CBD, offering a smooth, non-intoxicating experience perfect for everyday wellness and relaxation.\n\nThe bold sweet-tart berry pairs perfectly with crisp carbonation, delivering a refreshing drink that can be enjoyed chilled or served as a mocktail alternative. This CBD beverage provides a flavorful way to unwind without alcohol.\n\nMade with natural fruit juice and hemp extract, this beverage is crafted to deliver consistent quality and smooth effects for social gatherings or relaxing evenings.\n\nBrowse more CBD-infused beverages in our CBD Drinks collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Ripe blackberry flavor\n• Rich berry sweetness\n• Crisp sparkling finish\n\nWhy Choose This Product\n✔ 50mg CBD per can\n✔ Hemp-derived CBD beverage\n✔ Alcohol-free wellness drink\n✔ Bold sweet-tart berry flavor\n✔ Vegan, gluten-free, and non-GMO\n\nHow to Use\nStart with one can and wait about 30–60 minutes to understand the effects before consuming more.",
    "price": 5.99,
    "category": "drinks",
    "categoryLabel": "Drinks",
    "rating": 4.8,
    "image": "/images/wyld-cbd-sparkling-water-blackberry-50mg.webp",
    "thc": "< 0.3% THC",
    "cbd": "500gm CBD",
    "options": [
      "Single can",
      "4-pack"
    ],
    "benefits": [
      "• 50mg CBD per can",
      "• Bold blackberry flavor",
      "• Available as a single can or 4-pack",
      "• Refreshing, zero-sugar sparkling water"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 31,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Wyld CBD Sparkling Water – Blackberry 50mg | CBD American Shaman of Hurst",
    "metaDescription": "Shop Wyld CBD Sparkling Water – Blackberry 50mg at CBD American Shaman of Hurst. 50mg CBD per can. Bold blackberry flavor. Available as a single can or 4-pack. Shop CBD American Shaman of Hurst today.",
    "tags": "Wyld, CBD Sparkling Water, Blackberry, 50mg CBD, CBD Beverage, Hemp-Derived, Sparkling Water, CBD Drink, Wellness, Premium CBD, Ready-to-Drink, CBD",
    "altText": "Wyld CBD Sparkling Water Blackberry 50mg hemp-derived CBD beverage can",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "drinks",
      "all"
    ]
  },
  {
    "id": "60",
    "name": "Wyld CBD Sparkling Water – Blood Orange 50mg",
    "slug": "wyld-cbd-sparkling-water-blood-orange-50mg",
    "description": "Wyld CBD Sparkling Water – Blood Orange 50mg delivers a refreshing rich citrus with sweet berry undertones flavor infused with hemp-derived cannabinoids, offering a balanced and enjoyable cannabis beverage experience. What's Inside\n• 50mg CBD per can\n• Rich citrus with sweet berry undertones flavor\n• Sparkling CBD beverage\n• Sold individually or by pack",
    "longDescription": "About This Product\nWyld CBD Sparkling Water – Blood Orange 50mg combines the bold flavor of vibrant blood orange with hemp-derived cannabinoids to create a refreshing sparkling cannabis beverage. Each can contains 50mg of hemp-derived CBD, offering a smooth, non-intoxicating experience perfect for everyday wellness and relaxation.\n\nThe rich citrus with sweet berry undertones pairs perfectly with crisp carbonation, delivering a refreshing drink that can be enjoyed chilled or served as a mocktail alternative. This CBD beverage provides a flavorful way to unwind without alcohol.\n\nMade with natural fruit juice and hemp extract, this beverage is crafted to deliver consistent quality and smooth effects for social gatherings or relaxing evenings.\n\nBrowse more CBD-infused beverages in our CBD Drinks collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Bold blood orange flavor\n• Sweet-tart citrus notes\n• Crisp sparkling finish\n\nWhy Choose This Product\n✔ 50mg CBD per can\n✔ Hemp-derived CBD beverage\n✔ Alcohol-free wellness drink\n✔ Rich citrus with sweet berry undertones flavor\n✔ Vegan, gluten-free, and non-GMO\n\nHow to Use\nStart with one can and wait about 30–60 minutes to understand the effects before consuming more.",
    "price": 5.99,
    "category": "drinks",
    "categoryLabel": "Drinks",
    "rating": 4.8,
    "image": "/images/wyld-cbd-sparkling-water-blood-orange-50mg.webp",
    "thc": "< 0.3% THC",
    "cbd": "50mg",
    "options": [
      "Single can",
      "4-pack"
    ],
    "benefits": [
      "• 50mg CBD per can",
      "• Bold blood orange flavor",
      "• Available as single can or 4-pack",
      "• Zero-sugar sparkling water"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 30,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Wyld CBD Sparkling Water – Blood Orange 50mg | CBD American Shaman of Hurst",
    "metaDescription": "Shop Wyld CBD Sparkling Water – Blood Orange 50mg at CBD American Shaman of Hurst. 50mg CBD per can. Bold blood orange flavor. Available as single can or 4-pack. Shop CBD American Shaman of Hurst today.",
    "tags": "Wyld, CBD Sparkling Water, Blood Orange, 50mg CBD, CBD Beverage, Hemp-Derived, Sparkling Water, CBD Drink, Wellness, Premium CBD, Ready-to-Drink, CBD",
    "altText": "Wyld CBD Sparkling Water Blood Orange 50mg hemp-derived CBD beverage can",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "drinks",
      "all"
    ]
  },
  {
    "id": "59",
    "name": "Wyld CBD Sparkling Water – Grapefruit 20mg CBD + 10mg CBG",
    "slug": "wyld-cbd-sparkling-water-grapefruit-20mg-cbd-10mg-cbg",
    "description": "Wyld CBD Sparkling Water – Grapefruit is a refreshing sparkling beverage featuring bright grapefruit flavor with tangy citrus notes and subtle sweetness, infused with 20 mg CBD and 10 mg CBG per can.\n\nWhat's Inside\n20 mg CBD + 10 mg CBG per can\nBright grapefruit flavor with tangy citrus and subtle sweetness\nSparkling hemp-derived cannabinoid beverage\nSold individually or by pack\nThird-party lab tested for quality and consistency",
    "longDescription": "About This Product\n\nWyld CBD Sparkling Water – Grapefruit blends the vibrant taste of grapefruit with crisp sparkling water and a balanced cannabinoid profile featuring 20 mg of hemp-derived CBD and 10 mg of hemp-derived CBG per can.\n\nCrafted with real fruit flavor and premium hemp-derived cannabinoids, this alcohol-free sparkling beverage offers a refreshing option for those looking to enjoy cannabinoids in a convenient drink format. The bright citrus flavor and light carbonation make it enjoyable straight from the can or served chilled.\n\nMade with quality ingredients and independently third-party lab tested for purity and consistency, Wyld CBD Sparkling Water – Grapefruit is available at CBD American Shaman of Hurst, Hurst's trusted source for premium hemp products.\n\nBrowse more hemp-infused beverages in the CBD American Shaman of Hurst CBD Drinks collection.\n\nTaste & Aroma\n\n• Bright grapefruit citrus flavor\n• Light tart notes with subtle sweetness\n• Crisp, refreshing sparkling finish\n\nWhy Choose This Product\n\n✔ 20 mg CBD + 10 mg CBG per can\n✔ Sparkling hemp-derived cannabinoid beverage\n✔ Bright grapefruit flavor\n✔ Alcohol-free beverage\n✔ Vegan, gluten-free, and non-GMO\n✔ Third-party lab tested for quality and consistency\n\nHow to Use\n\nEnjoy one chilled can as directed on the product label. If you're new to cannabinoid beverages, start with one serving and allow sufficient time to assess your individual response before consuming more.",
    "price": 5.99,
    "category": "drinks",
    "categoryLabel": "Drinks",
    "rating": 4.8,
    "image": "/images/wyld-cbd-sparkling-water-grapefruit-50mg.webp",
    "thc": "< 0.3% THC",
    "cbd": "50mg",
    "options": [
      "Single can",
      "4-pack"
    ],
    "benefits": [
      "• 20mg CBD + 10mg CBG per can",
      "• Bright grapefruit flavor",
      "• Available as single can or case of 4",
      "• Zero-sugar sparkling water"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": true,
    "isNew": false,
    "metaTitle": "Wyld CBD Sparkling Water – Grapefruit 20mg CBD + 10mg CBG",
    "metaDescription": "Shop Wyld CBD Sparkling Water – Grapefruit 20mg CBD + 10mg CBG at CBD American Shaman of Hurst. Bright grapefruit flavor, zero-sugar, single can or case of 4 available now.",
    "tags": "Wyld, CBD Sparkling Water, Grapefruit, 50mg CBD, CBD Beverage, Hemp-Derived, Sparkling Water, CBD Drink, Wellness, Premium CBD, Ready-to-Drink",
    "altText": "Wyld CBD Sparkling Water Grapefruit 50mg hemp-derived CBD beverage can",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-21T03:25:23.068+00:00",
    "categories": [
      "drinks",
      "all"
    ]
  },
  {
    "id": "62",
    "name": "Wyld CBD Sparkling Water – Lemon 50mg",
    "slug": "wyld-cbd-sparkling-water-lemon-50mg",
    "description": "Wyld CBD Sparkling Water – Lemon 50mg delivers a refreshing bright zesty citrus flavor infused with hemp-derived cannabinoids, offering a balanced and enjoyable cannabis beverage experience. What's Inside\n• 50mg CBD per can\n• Bright zesty citrus flavor\n• Sparkling CBD beverage\n• Sold individually or by pack",
    "longDescription": "About This Product\nWyld CBD Sparkling Water – Lemon 50mg combines the bold flavor of fresh lemon with hemp-derived cannabinoids to create a refreshing sparkling cannabis beverage. Each can contains 50mg of hemp-derived CBD, offering a smooth, non-intoxicating experience perfect for everyday wellness and relaxation.\n\nThe bright zesty citrus pairs perfectly with crisp carbonation, delivering a refreshing drink that can be enjoyed chilled or served as a mocktail alternative. This CBD beverage provides a flavorful way to unwind without alcohol.\n\nMade with natural fruit juice and hemp extract, this beverage is crafted to deliver consistent quality and smooth effects for social gatherings or relaxing evenings.\n\nBrowse more CBD-infused beverages in our CBD Drinks collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Bright lemon citrus flavor\n• Light sweet notes\n• Crisp sparkling finish\n\nWhy Choose This Product\n✔ 50mg CBD per can\n✔ Hemp-derived CBD beverage\n✔ Alcohol-free wellness drink\n✔ Bright zesty citrus flavor\n✔ Vegan, gluten-free, and non-GMO\n\nHow to Use\nStart with one can and wait about 30–60 minutes to understand the effects before consuming more.",
    "price": 5.99,
    "category": "drinks",
    "categoryLabel": "Drinks",
    "rating": 4.8,
    "image": "/images/wyld-cbd-sparkling-water-lemon-50mg.webp",
    "thc": "< 0.3% THC",
    "cbd": "50mg",
    "options": [
      "Single can (12 fl oz)",
      "4-pack"
    ],
    "benefits": [
      "• 50mg CBD per can",
      "• Crisp lemon flavor",
      "• Available as single can or 4-pack",
      "• Refreshing, zero-sugar sparkling water"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 38,
    "isBestSeller": true,
    "isNew": false,
    "metaTitle": "Wyld CBD Sparkling Water – Lemon 50mg | CBD American Shaman of Hurst TX",
    "metaDescription": "Shop Wyld CBD Sparkling Water – Lemon 50mg at CBD American Shaman of Hurst. 50mg CBD per can. Crisp lemon flavor. Available as single can or 4-pack. Order online for Texas delivery.",
    "tags": "Wyld, CBD Sparkling Water, Lemon, 50mg CBD, CBD Beverage, Hemp-Derived, Sparkling Water, CBD Drink, Wellness, Premium CBD, Ready-to-Drink",
    "altText": "Wyld CBD Sparkling Water Lemon 50mg hemp-derived CBD beverage can",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "drinks",
      "all"
    ]
  },
  {
    "id": "61",
    "name": "Wyld CBD Sparkling Water – Raspberry 50mg",
    "slug": "wyld-cbd-sparkling-water-raspberry-50mg",
    "description": "Wyld CBD Sparkling Water – Raspberry 50mg delivers a refreshing sweet-tart berry flavor infused with hemp-derived cannabinoids, offering a balanced and enjoyable cannabis beverage experience. What's Inside\n• 50mg CBD per can\n• Sweet-tart berry flavor\n• Sparkling CBD beverage\n• Sold individually or by pack",
    "longDescription": "About This Product\nWyld CBD Sparkling Water – Raspberry 50mg combines the bold flavor of ripe raspberries with hemp-derived cannabinoids to create a refreshing sparkling cannabis beverage. Each can contains 50mg of hemp-derived CBD, offering a smooth, non-intoxicating experience perfect for everyday wellness and relaxation.\n\nThe sweet-tart berry pairs perfectly with crisp carbonation, delivering a refreshing drink that can be enjoyed chilled or served as a mocktail alternative. This CBD beverage provides a flavorful way to unwind without alcohol.\n\nMade with natural fruit juice and hemp extract, this beverage is crafted to deliver consistent quality and smooth effects for social gatherings or relaxing evenings.\n\nBrowse more CBD-infused beverages in our CBD Drinks collection at CBD American Shaman of Hurst in Hurst.\n\nTaste & Aroma\n• Sweet raspberry flavor\n• Light tart berry notes\n• Crisp sparkling finish\n\nWhy Choose This Product\n✔ 50mg CBD per can\n✔ Hemp-derived CBD beverage\n✔ Alcohol-free wellness drink\n✔ Sweet-tart berry flavor\n✔ Vegan, gluten-free, and non-GMO\n\nHow to Use\nStart with one can and wait about 30–60 minutes to understand the effects before consuming more.",
    "price": 5.99,
    "category": "drinks",
    "categoryLabel": "Drinks",
    "rating": 4.8,
    "image": "/images/wyld-cbd-sparkling-water-raspberry-50mg.webp",
    "thc": "< 0.3% THC",
    "cbd": "500gm CBD",
    "options": [
      "Single can (12 fl oz)",
      "4-pack"
    ],
    "benefits": [
      "• 50mg CBD per can",
      "• Bright raspberry flavor",
      "• Available as single can or 4-pack",
      "• Refreshing, zero-sugar sparkling water"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 18,
    "isBestSeller": true,
    "isNew": true,
    "metaTitle": "Wyld CBD Sparkling Water – Raspberry 50mg | CBD American Shaman of Hurst",
    "metaDescription": "Shop Wyld CBD Sparkling Water – Raspberry 50mg at CBD American Shaman of Hurst. 50mg CBD per can. Bright raspberry flavor. Available as single can or 4-pack. Shop CBD American Shaman of Hurst today.",
    "tags": "Wyld, CBD Sparkling Water, Raspberry, 50mg CBD, CBD Beverage, Hemp-Derived, Sparkling Water, CBD Drink, Wellness, Premium CBD, Ready-to-Drink, CBD",
    "altText": "Wyld CBD Sparkling Water Raspberry 50mg hemp-derived CBD beverage can",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "drinks",
      "all"
    ]
  },
  {
    "id": "191",
    "name": "Wyld Dark Cherry CBD + CBN + THC Gummies – 30ct",
    "slug": "wyld-dark-cherry-cbd-cbn-thc-gummies-30ct",
    "description": "Dark Cherry CBD + CBN + THC Gummies – Sleep Support is a premium hemp-derived product available at CBD American Shaman of Hurst in Hurst, TX. What's Inside\n• Premium hemp-derived formula\n• Lab-tested for purity and potency\n• Consistent, reliable dosing\n• Available exclusively at CBD American Shaman of Hurst, Hurst",
    "longDescription": "About This Product\nDark Cherry CBD + CBN + THC Gummies – Sleep Support is a carefully crafted hemp product available at CBD American Shaman of Hurst in Hurst, TX. Every unit is third-party lab tested to ensure purity, potency, and consistency.\n\nCBD American Shaman of Hurst is Hurst's trusted source for premium hemp-derived products including CBD, Delta-9, and specialty wellness items. We carry only brands we believe in, verified for quality at every step.\n\nWhy Choose This Product\n✔ Premium hemp-derived formula\n✔ Third-party lab tested for purity and potency\n✔ Precisely dosed for consistent, reliable effects\n✔ Available at CBD American Shaman of Hurst, Hurst, TX\n\nHow to Use\nFollow the product label instructions. Start low and go slow, especially if new to hemp products. Consult a healthcare professional if you have any questions about dosage or interactions.",
    "price": 59.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/dark-cherry-cbd-cbn-thc-gummies-sleep-support.webp",
    "thc": "< 0.3% THC",
    "cbd": "500mg CBD",
    "options": [
      "30-count"
    ],
    "benefits": [
      "• CBD + CBN + THC blend gummies",
      "• Dark cherry flavor",
      "• 30-count bottle",
      "• Formulated to support restful sleep"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Wyld Dark Cherry CBD + CBN + THC Gummies – 30ct | CBD American Shaman of Hurst",
    "metaDescription": "Shop Wyld Dark Cherry CBD + CBN + THC Gummies – 30ct at CBD American Shaman of Hurst. CBD + CBN + THC blend gummies. Dark cherry flavor. 30-count bottle. Available now at CBD American Shaman of Hurst.",
    "tags": "Dark Cherry Gummies, CBD Gummies, CBN Gummies, THC Gummies, Sleep Support, Hemp-Derived, Hemp Gummies, Edibles, Wellness, Nighttime Gummies, Cherry Flavor, Premium Gummies",
    "altText": "Dark Cherry CBD, CBN, and THC Sleep Support Gummies in dark cherry flavor package.",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "184",
    "name": "Wyld Marionberry Indica THC Gummies – 10mg",
    "slug": "wyld-marionberry-indica-thc-gummies-10mg",
    "description": "Marionberry Indica THC Gummies – 10mg is a premium hemp-derived product available at CBD American Shaman of Hurst in Hurst, TX. What's Inside\n• Premium hemp-derived formula\n• Lab-tested for purity and potency\n• Consistent, reliable dosing\n• Available exclusively at CBD American Shaman of Hurst, Hurst",
    "longDescription": "About This Product\nMarionberry Indica THC Gummies – 10mg is a carefully crafted hemp product available at CBD American Shaman of Hurst in Hurst, TX. Every unit is third-party lab tested to ensure purity, potency, and consistency.\n\nCBD American Shaman of Hurst is Hurst's trusted source for premium hemp-derived products including CBD, Delta-9, and specialty wellness items. We carry only brands we believe in, verified for quality at every step.\n\nWhy Choose This Product\n✔ Premium hemp-derived formula\n✔ Third-party lab tested for purity and potency\n✔ Precisely dosed for consistent, reliable effects\n✔ Available at CBD American Shaman of Hurst, Hurst, TX\n\nHow to Use\nFollow the product label instructions. Start low and go slow, especially if new to hemp products. Consult a healthcare professional if you have any questions about dosage or interactions.",
    "price": 64.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/marionberry-indica-thc-gummies-10mg.webp",
    "thc": "< 0.3% THC",
    "cbd": "10mg",
    "options": [
      "10-count",
      "30-count"
    ],
    "benefits": [
      "• 10mg Delta 9 THC per gummy",
      "• Indica-leaning marionberry flavor",
      "• Available in 10-count and 30-count sizes",
      "• Third-party lab tested hemp-derived THC"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Wyld Marionberry Indica THC Gummies – 10mg | CBD American Shaman of Hurst",
    "metaDescription": "Shop Wyld Marionberry Indica THC Gummies – 10mg at CBD American Shaman of Hurst. 10mg Delta 9 THC per gummy, marionberry flavor, available in 10-count and 30-count sizes today.",
    "tags": "Marionberry, Indica Gummies, THC Gummies, 10mg THC, Hemp Gummies, Hemp-Derived, THC Edibles, Marionberry Flavor, Premium Gummies, Cannabis Gummies, Wellness, Edibles",
    "altText": "Marionberry Indica THC Gummies 10mg hemp-derived gummy package",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "193",
    "name": "Wyld Pomegranate THC + CBD Gummies – 10mg",
    "slug": "wyld-pomegranate-thc-cbd-gummies-10mg",
    "description": "Pomegranate THC + CBD Gummies – 10mg is a premium hemp-derived product available at CBD American Shaman of Hurst in Hurst, TX. What's Inside\n• Premium hemp-derived formula\n• Lab-tested for purity and potency\n• Consistent, reliable dosing\n• Available exclusively at CBD American Shaman of Hurst, Hurst",
    "longDescription": "About This Product\nPomegranate THC + CBD Gummies – 10mg is a carefully crafted hemp product available at CBD American Shaman of Hurst in Hurst, TX. Every unit is third-party lab tested to ensure purity, potency, and consistency.\n\nCBD American Shaman of Hurst is Hurst's trusted source for premium hemp-derived products including CBD, Delta-9, and specialty wellness items. We carry only brands we believe in, verified for quality at every step.\n\nWhy Choose This Product\n✔ Premium hemp-derived formula\n✔ Third-party lab tested for purity and potency\n✔ Precisely dosed for consistent, reliable effects\n✔ Available at CBD American Shaman of Hurst, Hurst, TX\n\nHow to Use\nFollow the product label instructions. Start low and go slow, especially if new to hemp products. Consult a healthcare professional if you have any questions about dosage or interactions.",
    "price": 34.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/pomegranate-thc-cbd-gummies-10mg.webp",
    "thc": "< 0.3% THC",
    "cbd": "10mg",
    "options": [
      "30-count",
      "10-count ($34.99)"
    ],
    "benefits": [
      "• 10mg THC + CBD per gummy",
      "• Pomegranate flavor",
      "• Available in 30-count or 10-count ($34.99)",
      "• Third-party lab tested"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 24,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Wyld Pomegranate THC + CBD Gummies – 10mg | CBD American Shaman of Hurst",
    "metaDescription": "Shop Wyld Pomegranate THC + CBD Gummies – 10mg at CBD American Shaman of Hurst. 10mg THC + CBD per gummy. Pomegranate flavor. Available in 30-count or 10-count ($34.99). Order...",
    "tags": "Pomegranate Gummies, THC Gummies, CBD Gummies, THC + CBD, 10mg THC, Hemp Gummies, Hemp-Derived, Edibles, Pomegranate Flavor, Premium Gummies, Wellness, Balanced Formula",
    "altText": "Pomegranate THC and CBD Gummies 10mg hemp-derived gummy package",
    "created_at": "2026-08-20T18:28:06.053+00:00",
    "updated_at": "2026-08-20T18:28:06.053+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  },
  {
    "id": "199",
    "name": "Wyld THC-Free Peach CBD Gummies – 40ct",
    "slug": "wyld-thc-free-peach-cbd-gummies-40ct",
    "description": "Wyld THC-Free Peach CBD Gummies is a premium hemp-derived product available at CBD American Shaman of Hurst in Hurst, TX. What's Inside\n• Premium hemp-derived formula\n• Lab-tested for purity and potency\n• Consistent, reliable dosing\n• Available exclusively at CBD American Shaman of Hurst, Hurst",
    "longDescription": "About This Product\nWyld THC-Free Peach CBD Gummies is a carefully crafted hemp product available at CBD American Shaman of Hurst in Hurst, TX. Every unit is third-party lab tested to ensure purity, potency, and consistency.\n\nCBD American Shaman of Hurst is Hurst's trusted source for premium hemp-derived products including CBD, Delta-9, and specialty wellness items. We carry only brands we believe in, verified for quality at every step.\n\nWhy Choose This Product\n✔ Premium hemp-derived formula\n✔ Third-party lab tested for purity and potency\n✔ Precisely dosed for consistent, reliable effects\n✔ Available at CBD American Shaman of Hurst, Hurst, TX\n\nHow to Use\nFollow the product label instructions. Start low and go slow, especially if new to hemp products. Consult a healthcare professional if you have any questions about dosage or interactions.",
    "price": 64.99,
    "category": "gummies",
    "categoryLabel": "Gummies",
    "rating": 4.8,
    "image": "/images/wyld-thc-free-peach-cbd-gummies.webp",
    "thc": "0.0% THC (Zero THC)",
    "cbd": "20 mg CBD; 10mg CBC",
    "options": [
      "40-count"
    ],
    "benefits": [
      "• 20mg CBD + 10mg CBC per gummy",
      "• THC-free formula",
      "• Peach flavor",
      "• Third-party lab tested"
    ],
    "labResults": {
      "purity": "99.80%",
      "solventFree": true,
      "cannabinoids": "Farm Bill Compliant Phytocannabinoid Profile",
      "pesticidesPass": true,
      "heavyMetalsPass": true
    },
    "reviewsCount": 25,
    "isBestSeller": false,
    "isNew": false,
    "metaTitle": "Wyld THC-Free Peach CBD Gummies 40ct | CBD American Shaman of Hurst Texas",
    "metaDescription": "Shop Wyld THC-Free Peach CBD Gummies – 40ct at CBD American Shaman of Hurst. 20mg CBD + 10mg CBC per gummy. THC-free formula. Peach flavor. Order online for Texas delivery.",
    "tags": "Wyld, THC-Free, Peach CBD Gummies, CBD Gummies, Hemp-Derived, Peach Flavor, CBD Edibles, Premium CBD, Wellness, Daily Wellness, Hemp Gummies, CBD",
    "altText": "Wyld THC-Free Peach CBD Gummies hemp-derived peach flavored gummy package",
    "created_at": "2026-08-20T18:28:06.054+00:00",
    "updated_at": "2026-08-20T18:28:06.054+00:00",
    "categories": [
      "gummies",
      "all"
    ]
  }
];
